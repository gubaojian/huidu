<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DateFormat
 *
 * @author baobao
 */
class DateFormatPattern {
    
    /**
     * 日期时间格式
     */
    const MYSQL_DATE_FORMAT = "Y-m-d H:i:s";
}

?>
