<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_list
 *
 * @author baobao
 */
$RECORD_LIST_TITLE = "Track Record List";

$NO_RECORD_LIST_TIPS = "No Track Record List!";

?>
