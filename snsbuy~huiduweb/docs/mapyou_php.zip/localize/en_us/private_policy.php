<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of private_policy
 *
 * @author baobao
 */


$PRIVATE_POLICY_TITLE = "Privacy Statement";

$PRIVATE_POLICY_TIPS = "Privacy Statement";


$PRIVATE_POLICY_INFO = "Remote GPS Locator pays great attention to the protection of  your or your friend's (family's) privacy, any of your privacy information won't be collected. We use powerful security technology to prevent your friend's (family's) location from leaking, so you can rest assured of use it.";



?>
