<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of map
 *
 * @author baobao
 */


/**
 *   远程定位请求提示信息
 */
$REMOTE_LOCATOR_TITLE = "Request For Remote GPS Locating";
$REMOTE_LOCATOR_INFO = "You see this page because you have a friend (family) that sends you a request for remote GPS locating. Click Ok on the dialog if you allow him (her) to get your location; Otherwise, click Don't Allow.";

/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "Remote GPS Locating Failed, Because you reject The Request.";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "Remote GPS Locating Failed because of Locating Service not found and Locating Timeout.";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "Remote GPS locating failed, because your browser don't support geographical location.";
$LOCATOR_SUCCESS_TIPS = "Remote GPS locating success, your location has delivered to your friend (family).";
$LOCATOR_ABOUT_LINK = "<a href=\"https://itunes.apple.com/app/remote-gps-locator/id579919955?ls=1&mt=8\" >Remote GPS Locator</a> tips: ";

$LOCATION_TIPS_CLASS_NAME  = "content-info-div-en-us";




?>
