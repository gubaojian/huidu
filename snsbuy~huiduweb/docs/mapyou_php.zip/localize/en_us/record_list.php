<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_list
 *
 * @author baobao
 */
$RECORD_LIST_TITLE = "Remote Locating List";

$NO_RECORD_LIST_TIPS = "No Location Record!";



/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "Locating Was Rejected";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "Locating Timeout";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "Device Not Support GPS Location";
$LOCATOR_WAIT_FOR_CLICK_TIPS = "Wait For Clicking";
$LOCATOR_SUCCESS_TIPS = "Locating Success";



?>
