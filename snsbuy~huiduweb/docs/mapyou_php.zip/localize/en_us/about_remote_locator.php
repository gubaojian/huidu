<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of about_remote_locator
 *
 * @author baobao
 */

$ABOUT_REMOTE_LOCATOR_TITLE = "About Remote GPS Locator";

$ABOUT_REMOTE_LOCATOR_TIPS = "About Remote GPS Locator";


$ABOUT_REMOTE_LOCATOR_INFO = "Remote GPS Locator is a tool for locating the location of your friend (family) without installing any software on his (her) phone. No matter what mobile system he (her) uses; iOS, Android, Windows Mobile even BlackBerry OS. what you do is just send a message (email) to him (her), then you will get his (her) location when he(she) opens the link in the message (email). we only keep the latest 30 records in three month for you, other records will be deleted by server automatically.";


?>
