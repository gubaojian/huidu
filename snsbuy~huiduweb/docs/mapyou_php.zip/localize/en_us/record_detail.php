<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_detail
 *
 * @author baobao
 */

/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "Remote GPS locating failed, because your frined (family) reject the request.";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "Remote GPS locating failed because of locating timeout.";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "Remote GPS locating failed, because your frined's (family's) device don't support locating.";
$LOCATOR_WAIT_FOR_CLICK_TIPS = "Wait for your friend's (family's) clicking on the request link.";
$LOCATOR_SUCCESS_TIPS = "Remote GPS locating success.";

$SEND_TIME_TEXT ="send time :";
$LOCATING_TIME_TEXT = "locate time:";

$LOCATION_DETAIL = "Remote GPS Locating Detail";

$OPEN_IN_MAP = "Open Location In Map";

$RESULT_TIPS_DETAIL_STYLE = "text-indent:2em;text-align:justify;text-justify:inter-ideograph;font-size: 16px;";


?>
