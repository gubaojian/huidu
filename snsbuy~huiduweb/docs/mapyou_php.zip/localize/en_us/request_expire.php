<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of request_expire
 *
 * @author baobao
 */
  //不采用模板

$REQUEST_EXPORED_TITLE = "Request expired";

$REQUEST_EXPORED_TIPS = "Request was expired.";

$REQUEST_EXPORED_INFO = "You see this page, because your request has been processed. The link was expired, it was made from <a href=\"https://itunes.apple.com/app/remote-gps-locator/id579919955?ls=1&mt=8\" >Remote GPS Locator</a>.";

$LOCATION_TIPS_CLASS_NAME  = "content-info-div-en-us";

?>
