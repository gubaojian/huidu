<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_list
 *
 * @author baobao
 */
$RECORD_LIST_TITLE = "追踪记录列表";

$NO_RECORD_LIST_TIPS = "暂时无追踪记录!";

?>
