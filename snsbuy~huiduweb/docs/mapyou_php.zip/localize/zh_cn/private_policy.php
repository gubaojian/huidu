<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of private_policy
 *
 * @author baobao
 */


$PRIVATE_POLICY_TITLE = "隐私声明";

$PRIVATE_POLICY_TIPS = "隐私声明";


$PRIVATE_POLICY_INFO = "远程定位软件非常重视对您以及您朋友（家人）的隐私的保护，不会收集关于您的任何隐私信息。远程定位时，软件采用独特安全的技术，确保您朋友（家人）的位置信息不被泄露，请放心使用本软件。";

?>
