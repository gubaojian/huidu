<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_list
 *
 * @author baobao
 */
$RECORD_LIST_TITLE = "远程定位记录列表";

$NO_RECORD_LIST_TIPS = "暂无远程定位记录!";



/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "您的朋友（家人）拒绝远程定位请求";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "远程定位超时";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "您朋友（家人）的设备不支持远程定位";
$LOCATOR_WAIT_FOR_CLICK_TIPS = "等待对方点击定位链接";
$LOCATOR_SUCCESS_TIPS = "定位成功";

?>
