<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_detail
 *
 * @author baobao
 */
/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "您的朋友（家人）拒绝远程定位请求。";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "远程定位超时。";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "您朋友（家人）的设备不支持远程定位。";
$LOCATOR_WAIT_FOR_CLICK_TIPS = "等待对方点击定位链接。";
$LOCATOR_SUCCESS_TIPS = "远程定位成功。";


$SEND_TIME_TEXT ="发送时间：";
$LOCATING_TIME_TEXT = "定位时间：";

$LOCATION_DETAIL = "远程定位详情";

$OPEN_IN_MAP = "在地图中查看位置";

//样式
$RESULT_TIPS_DETAIL_STYLE = "text-indent:2em;text-align:justify;text-justify:inter-ideograph;font-size: 16px;";


?>
