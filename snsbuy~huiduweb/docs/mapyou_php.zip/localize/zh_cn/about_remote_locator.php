<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of about_remote_locator
 *
 * @author baobao
 */


$ABOUT_REMOTE_LOCATOR_TITLE = "关于远程定位";

$ABOUT_REMOTE_LOCATOR_TIPS = "关于远程定位";


$ABOUT_REMOTE_LOCATOR_INFO = "远程定位器是一个用于远程定位你的朋友（家人）的工具，对方手机无需安装任何软件，你只需要向对方发送一个短信或者邮件，不论他使用的是iOS、Android、Windows Mobile还是BlackBerry，都可获知对方的位置。一条短信，一封邮件，轻松定位您朋友（家人）的位置。软件及保存最近三个月内的30条定位记录，其它定位记录会被服务器自动删除。";


?>
