<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of request_expire
 *
 * @author baobao
 */

$REQUEST_EXPORED_TITLE = "请求已过期";

$REQUEST_EXPORED_TIPS = "您的请求已过期";

$REQUEST_EXPORED_INFO = "<a href=\"https://itunes.apple.com/app/remote-gps-locator/id579919955?ls=1&mt=8\" >远程定位器</a>提示您：您看到此页面，是因为您的请求链接已被处理过，链接已失效。";

$LOCATION_TIPS_CLASS_NAME  = "content-info-div-zh-cn";

?>
