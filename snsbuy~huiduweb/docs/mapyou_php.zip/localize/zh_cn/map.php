<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of map
 *
 * @author baobao
 */
/**
 *   远程定位请求提示信息
 */
$REMOTE_LOCATOR_TITLE = "远程定位请求";
$REMOTE_LOCATOR_INFO = "您看到此页面，是因为您的某位朋友（家人）向您发送了一条“远程定位”的请求信息。若您希望这位朋友（家人）获知您的位置，请在弹出使用位置的对号框中点击好；
    否则，请点击不允许。";

/**
 *   远程定位结果展示页面
 */
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW = "您拒绝了这位朋友（家人）的远程定位请求，远程定位失败。";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT = "启用定位服务失败，定位超时，远程定位失败。";
$LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT = "您的浏览器不支持地理位置定位，远程定位失败。";
$LOCATOR_SUCCESS_TIPS = "远程定位成功，您的朋友（家人）成功获知了您的位置。";
$LOCATOR_ABOUT_LINK = "<a href=\"https://itunes.apple.com/app/remote-gps-locator/id579919955?ls=1&mt=8\" >远程定位器</a>提示：";

$LOCATION_TIPS_CLASS_NAME  = "content-info-div-zh-cn";

?>
