<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of apns_feedback
 *
 * @author baobao
 */
print_r($_GET);

print_r($_POST);

?>
