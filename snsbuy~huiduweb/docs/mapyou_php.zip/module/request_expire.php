<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of request_expire
 *
 * @author baobao
 */
  //不采用模板
 $ASSEMBLE_RUMTIME_NO_HEADER_FOOTER = true;

?>
