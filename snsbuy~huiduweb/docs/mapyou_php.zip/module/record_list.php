<?php
include_once dirname(__FILE__).'/../biz/ao/TrackLocationAO.php';
include_once dirname(__FILE__).'/../utils/ServerUtils.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_list
 *
 * @author baobao
 */

if(!isset($_GET['uuid']) || !isset($_GET['key'])){
    die();
}

$uuid = $_GET['uuid'];

$key = $_GET['key'];

$pageNum = 1;

if(isset($_GET['pageNum'])){
    $pageNum = intval($_GET['pageNum']);
}
if( $pageNum < 1){
    $pageNum = 1;
}

$pageNum = 1;




$result = TrackLocationAO::findTrackLocationList($uuid, $key, $pageNum);

$pagination = $result->result->pagination;

$locationDOList = $result->result->result;

?>
