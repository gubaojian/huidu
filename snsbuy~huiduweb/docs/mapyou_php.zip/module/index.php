<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of index
 *
 * @author baobao
 */
 $ASSEMBLE_RUMTIME_NO_HEADER_FOOTER = true;

?>
