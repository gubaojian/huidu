<?php
include_once dirname(__FILE__).'/../biz/ao/TrackLocationAO.php';
include_once dirname(__FILE__).'/../utils/ServerUtils.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of map
 *
 * @author baobao
 */
if(!isset($_GET['trackUuid'])  || !isset($_GET['trackKey'])){
    print_r("trackuuid is null");
    die();
}

$trackUuid = $_GET['trackUuid'];
$trackKey = $_GET['trackKey'];

$result = TrackLocationAO::checkForTrackRecordByUuid($trackUuid, $trackKey);

if(!$result->success){
    header("Location:".ServerUtils::getRequestPath()."/request_expire.php");
    die();
}

  //不采用模板
 $ASSEMBLE_RUMTIME_NO_HEADER_FOOTER = true;

?>
