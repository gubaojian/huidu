<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of about_remote_locator
 *
 * @author baobao
 */


 $ASSEMBLE_RUMTIME_NO_HEADER_FOOTER = true;

?>
