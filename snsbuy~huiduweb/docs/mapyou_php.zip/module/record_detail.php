<?php
include_once dirname(__FILE__).'/../biz/ao/TrackLocationAO.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record_detail
 *
 * @author baobao
 */
if(!isset($_GET['trackKey']) || !isset($_GET['trackUuid'])){
    die();
}

$trackKey  = $_GET['trackKey'];
$trackUuid = $_GET['trackUuid']; 

$result = TrackLocationAO::getTrackLocationForDetail($trackUuid, $trackKey);

if(!$result->success){
    die();
}


$locationDO = $result->result;


?>
