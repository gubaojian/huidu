
<?php if($result->success && isset($locationDOList) &&  $pagination->getTotalRecord() > 0){?>
 <div data-role="header" data-theme="c" >
        <h4><?php echo $RECORD_LIST_TITLE; ?></h4>
 </div>
<?php } ?>


    <div data-role="content" class="ui-content" role="main">	
        
        <?php if($result->success && isset($locationDOList) &&  $pagination->getTotalRecord() > 0){?>
         <ul data-role="listview">
            <?php foreach ($locationDOList as $locationDO) {?>
              <li id="<?php echo   $locationDO->id; ?>">
                 <a href="<?php
                 $params = array("trackKey"=>$locationDO->trackKey,  "trackUuid"=>$locationDO->trackUuid);
                 echo ServerUtils::getRequestPath()."/record_detail.php?".http_build_query($params);
                 ?>"
                 target="_self">
                 
                    <?php if($locationDO->status == LocationStatus::GPRS_LOCATION_SUCCESS){  ?>
                         <h3  class="track_success" latitude="<?php echo $locationDO->latitude;?>" longtitude="<?php echo $locationDO->longitude; ?>">
                               <?php echo $LOCATOR_SUCCESS_TIPS; ?>
                         </h3>
                         <p>
                             <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y-m-d H:i:s"); } ?>
                         </p>

                   <?php 
                       }else if($locationDO->status == LocationStatus::GRPS_NOT_ALLOW){
                    ?>
                          <h3  class="track_denied">
                                <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW; ?>
                          </h3>
                          <p>
                              <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y-m-d H:i:s"); } ?>
                          </p>  
                     <?php
                       }else if($locationDO->status == LocationStatus::GPRS_LOCATION_TIMEOUT){ ?>
                          <h3  class="track_time_out"> 
                             <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT; ?>
                          </h3>
                          <p>
                              <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y-m-d H:i:s"); } ?>
                          </p>  
                     <?php
                         } else if($locationDO->status == LocationStatus::GRPS_NOT_SUPPORT){
                     ?>
                          <h3  class="track_not_support">
                                 <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT; ?>
                          </h3>
                          <p>
                                 <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y-m-d H:i:s"); } ?>
                          </p>     
                          
                     <?php } else if($locationDO->status == LocationStatus::WAIT_FOR_CLICK) {?>
                           <h3  class="track_wait_for_click">
                              <?php echo $LOCATOR_WAIT_FOR_CLICK_TIPS; ?>
                           </h3>
                           <p>
                                   <?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y-m-d H:i:s"); } ?>
                          </p>
                     <?php 
                        }else{
                     ?>  
                          <h3  class="track_denied">
                                <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT; ?>
                           </h3>
                           <p>
                                <?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y-m-d H:i:s"); } ?>
                           </p> 
                     <?php 
                        }
                     ?>
                 </a>
              </li>
            <?php } ?>
       </ul>
       <?php } else { // 没有数据 ?>
           <br/><br/><br/>
           <br/><br/><br/><br/>
          <h4  align="center"> <?php echo $NO_RECORD_LIST_TIPS; ?>  </h4>
          
       <?php } ?>
    </div> 
<script type="text/javascript">
    
    function readyFunction(){
        
        function connectWebViewJavascriptBridge(callback) {
           if (window.WebViewJavascriptBridge) {
                callback(WebViewJavascriptBridge)
            } else {
                document.addEventListener('WebViewJavascriptBridgeReady', function() {
                    callback(WebViewJavascriptBridge)
                }, false)
            }
        }
        
        connectWebViewJavascriptBridge(function(bridge) {
            /* Init your app here */
            bridge.init(function(message, responseCallback) {
                if (responseCallback) {
                    responseCallback("JavaScript Response Callback")
                }
         })
           
        chainedConvertLocationName();
        
        
        function chainedConvertLocationName(placeName){
           var tracks = jQuery(".track_success");
           if(!tracks){
               return;
           }
           
           for(var i=0; i<tracks.length; i++ ){
               var track = tracks[i];
               if(jQuery(track).attr("converted") == "0"){  //转换中
                   if(placeName){
                      jQuery(track).text(placeName);
                      jQuery(track).attr("converted", "1");
                      continue; 
                   }else{
                      convertToLocationName(jQuery(track).attr("latitude"), jQuery(track).attr("longtitude"), chainedConvertLocationName);
                      break; 
                   }
               }else if(jQuery(track).attr("converted") == "1"){ //已经更想过
                   continue;
               }else{ //为转换
                 jQuery(track).attr("converted", "0");
                 convertToLocationName(jQuery(track).attr("latitude"), jQuery(track).attr("longtitude"), chainedConvertLocationName);
                 break;
               }
           }
        }
        
            //convertToLocationName(30.28615719999999, 120.1204291);

            function convertToLocationName(latitude, longtitude, callback){
                var lat = latitude;
                var lng = longtitude;
                bridge.callHandler("geocode", {"latitude":latitude, "longitude": longtitude, "id":"22"}, function (placeName){
                     if(callback){
                         callback(placeName); 
                      }
                 });
            }
        });
     }
</script>
