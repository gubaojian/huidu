<!DOCTYPE html>
<html>
    <head>
         <title><?php echo $ABOUT_REMOTE_LOCATOR_TITLE; ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            *{margin:0 auto; padding:0 auto;}
             body { 
                background: #F9F9F9;
                max-width: 600px;
                min-height: 300px;
            }
           .content-font{
                font-size: 20px;
                margin-top: 20px;
            }
            .content-info-div{
                 margin-top: 6px;
                 margin-left: 6px;
                 margin-right: 6px;
                 text-indent:2em; 
                 line-height:120%;
                 font-size: 18px;
                 text-align:justify;   
                 text-justify:inter-ideograph;
            }
        </style>
    </head>
<body >
    <div id="content" class="content-font">
        <h3  align="center">
            <?php echo $ABOUT_REMOTE_LOCATOR_TIPS; ?>
        </h3>
        <div id="content-info-div"  class="content-info-div">
            <?php echo $ABOUT_REMOTE_LOCATOR_INFO; ?>
        </div>
    </div>
</body>
</html>