<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $APP_TITLE; ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            *{margin:0 auto; padding:0 auto;}
             body { 
                background: #F9F9F9;
                max-width: 600px;
                min-height: 300px;
            }
           .content-font{
                font-size: 20px;
                margin-top: 20px;
            }
            .content-info-div-zh-cn{
                 margin-top: 6px;
                 margin-left: 6px;
                 margin-right: 6px;
                 text-indent:0em; 
                 line-height:120%;
                 font-size: 18px;
                 text-align:justify;   
                 text-justify:inter-ideograph;
            }
            .content-info-div-en-us{
                 margin-top: 6px;
                 margin-left: 6px;
                 margin-right: 6px;
                 text-indent:1em; 
                 line-height:120%;
                 font-size: 18px;
                 text-align:justify;   
                 text-justify:inter-ideograph;
            }
        </style>
        <script type="text/javascript">            
            if ( document.addEventListener ){
               document.addEventListener( "DOMContentLoaded", 
                 function(){
                   handleCollectGeoLocationRequest();
                },
                false);
            } else if (document.attachEvent) {
                document.attachEvent("onreadystatechange", function(){
                     if(document.readyState != 'complete'){
                       return;
                     }
                     handleCollectGeoLocationRequest();
               });
           }

           function  handleCollectGeoLocationRequest(){
               
                locationData= {
                    "status" : null,
                    "accuracy": null,
                    "latitude"  : null,
                    "longitude" : null,
                    "trackUuid"  :"<?php echo $trackUuid; ?>",
                    "trackKey"  :"<?php echo $trackKey; ?>"  
                };
                
                
                
                if(navigator.geolocation)
                {
                    navigator.geolocation.getCurrentPosition(getPosition, getPositionError, {enableHighAccuracy:true, timeout:8000, maximumAge:1000});
                }else{
                    locationData.status = <?php echo LocationStatus::GRPS_NOT_SUPPORT; ?>;
                    ajaxGeoLocation(locationData);
                }
                
           
                /**获取位置*/
                function getPosition(position){
                    locationData.accuracy = position.coords.accuracy;
                    locationData.latitude = position.coords.latitude;
                    locationData.longitude = position.coords.longitude; 
                    locationData.status = <?php echo LocationStatus::GPRS_LOCATION_SUCCESS; ?>;
                    ajaxGeoLocation(locationData);
                }

                function getPositionError(error){
                        switch(error.code) 
                        {
                            case error.PERMISSION_DENIED:
                                locationData.status = <?php echo LocationStatus::GRPS_NOT_ALLOW; ?>;   
                                break;
                            case error.POSITION_UNAVAILABLE:
                                locationData.status = <?php echo LocationStatus::GPRS_LOCATION_TIMEOUT; ?>;
                                break;
                            case error.TIMEOUT:
                                locationData.status = <?php echo LocationStatus::GPRS_LOCATION_TIMEOUT; ?>;
                                break;
                            case error.UNKNOWN_ERROR:
                                locationData.status = <?php echo LocationStatus::GPRS_LOCATION_TIMEOUT; ?>;
                            break;
                        }
                        ajaxGeoLocation(locationData);
                }

                function ajaxGeoLocation(data){
                    var  request;
                    if(window.XMLHttpRequest){
                       request =  new XMLHttpRequest();
                    }else{
                       request = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    
                    request.open("POST", "track_geolocaition.php", true);  // asynchronously 
                    request.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    
                    var  query = "";
                    for(var key in data){
                        if(data[key]){
                            query +=(key + "=" + data[key] + "&");
                        } 
                    }
                    
                    request.send(query);  
                            
                    var tips = null;
                    if(locationData.status == <?php echo LocationStatus::GRPS_NOT_ALLOW; ?>){
                        tips = "<?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW; ?>";
                    }else if(locationData.status == <?php echo LocationStatus::GRPS_NOT_SUPPORT; ?>){
                        tips = "<?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT; ?>";
                    }else if(locationData.status == <?php echo LocationStatus::GPRS_LOCATION_TIMEOUT; ?>){
                        tips = "<?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT; ?>";
                    }else if(locationData.status == <?php echo LocationStatus::GPRS_LOCATION_SUCCESS; ?>){
                        tips = "<?php echo $LOCATOR_SUCCESS_TIPS; ?>";
                    }
                    var contentDiv = document.getElementById("content-info-div");
                    if(contentDiv){
                       if(contentDiv.innerHTML){
                           contentDiv.innerHTML   = '<?php echo $LOCATOR_ABOUT_LINK; ?>' + tips ;
                       }else if(contentDiv.innerText){
                           contentDiv.innerText = tips;
                       }else if(contentDiv.textContent){
                           contentDiv.textContent = tips;  
                       }
                    }
                    
                    // alert(request.responseText  + "   "  + query);
                }
               
           }
         </script>
    </head>
<body >
    <div id="content" class="content-font">
        <h4  align="center"><?php echo $REMOTE_LOCATOR_TITLE; ?> </h4>
        <div id="content-info-div"  class="<?php echo $LOCATION_TIPS_CLASS_NAME; ?>">
            <?php echo $REMOTE_LOCATOR_INFO; ?>
        </div>
    </div>
</body>
</html>