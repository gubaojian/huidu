<!DOCTYPE html>
<html class="ui-mobile">
    <head>
        <title>远程定位</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
      
        <style>
            .hiddenItem{
                visiblity:hidden;
            }
            body.ui-mobile-viewport, div.ui-mobile-viewport {
            overflow-x: hidden;
            }
            .ui-mobile, .ui-mobile body {
            height: 100%;
            }
            .ui-mobile-viewport {
            margin: 0;
            overflow-x: visible;
            -webkit-text-size-adjust: none;
            -ms-text-size-adjust: none;
            -webkit-tap-highlight-color: rgba(0,0,0,0);
            }
            .ui-overlay-c {
            background-image: none;
            border-width: 0;
            }
            .ui-body-c, .ui-overlay-c {
            border: 1px solid #AAA;
            color: #333;
            text-shadow: 0 1px 0 white;
            background: #F9F9F9;
            background-image: -webkit-gradient(linear,left top,left bottom,from(#F9F9F9),to(#EEE));
            background-image: -webkit-linear-gradient(#F9F9F9,#EEE);
            background-image: -moz-linear-gradient(#F9F9F9,#EEE);
            background-image: -ms-linear-gradient(#F9F9F9,#EEE);
            background-image: -o-linear-gradient(#F9F9F9,#EEE);
            background-image: linear-gradient(#F9F9F9,#EEE);
            }


            .ui-content {
            border-width: 0;
            overflow: visible;
            overflow-x: hidden;
            padding: 15px;
            }
        </style>

    </head>
<body class="ui-mobile-viewport ui-overlay-c" style="height: 100%; ">
<div data-role="page" 
     tabindex="0" class="type-interior ui-page ui-body-c ui-page-active" style="min-height: 100%; ">
<div  data-role="content" class="ui-content" role="main">
   <strong>
       <?php 
          echo $HELLO_WORLD_TEXT;
       ?>
   </strong>
</div>
</div>
 </body>
</html>
