 <?php 
  if(!$result->success){
      die();
  }
?>


<div data-role="header" data-theme="c" >
        <h4 align="center"><?php echo $LOCATION_DETAIL; ?></h4>
 </div>

<?php 
  if($locationDO->status == LocationStatus::GPRS_LOCATION_SUCCESS){
?>
<div data-role="content" class="ui-content" role="main">
    <div style="width: 100%;text-align: center;margin-top: -10px;font-size: 14px;font-weight:bolder;" class="track_success" latitude="<?php echo $locationDO->latitude;?>" longtitude="<?php echo $locationDO->longitude; ?>">
            <?php echo $LOCATOR_SUCCESS_TIPS; ?>
    </div>
     <div style="text-align:center;font-size: 12px;"> 
        latitude: <?php echo $locationDO->latitude; ?>
        <br/>
        longitude: <?php echo $locationDO->longitude; ?>
    </div>
    <div style="text-align:center;font-size: 12px;"> 
        <?php echo $LOCATING_TIME_TEXT; ?> 
            <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y/m/d H:i:s"); } ?>
    </div>
    <div style="text-align:center;font-size: 12px;"> 
        <?php echo $SEND_TIME_TEXT; ?> 
            <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y/m/d H:i:s"); } ?>
    </div>
    
    <br/>
     <div style="width: 100%;text-align: center;font-size: 16px;font-weight:bolder;">
         <a href="javascript:void(0)"  class="open_map" latitude="<?php echo $locationDO->latitude;?>" longtitude="<?php echo $locationDO->longitude; ?>">  <?php echo $OPEN_IN_MAP; ?> </a>
    </div>
   
</div>
<?php }else if($locationDO->status == LocationStatus::GPRS_LOCATION_TIMEOUT){?>

<div data-role="content" class="ui-content" role="main">
     <h3 align="center" style="<?php echo $RESULT_TIPS_DETAIL_STYLE;?>" >
           <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_TIMEOUT; ?>
     </h3>
    <div style="text-align:center;">    <?php echo $LOCATING_TIME_TEXT; ?><?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y/m/d H:i:s"); } ?></div>
    <div style="text-align:center;">  <?php echo $SEND_TIME_TEXT; ?><?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y/m/d H:i:s"); } ?></div>
</div>

<?php } else if($locationDO->status == LocationStatus::GRPS_NOT_ALLOW){?>

<div data-role="content" class="ui-content" role="main">
      <h2 align="center" style="<?php echo $RESULT_TIPS_DETAIL_STYLE;?>" >
          <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_ALLOW ; ?>
      </h2>
     <div style="text-align:center;">    <?php echo $LOCATING_TIME_TEXT; ?> <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y/m/d H:i:s"); } ?></div>
     <div style="text-align:center;">  <?php echo $SEND_TIME_TEXT; ?> <?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y/m/d H:i:s"); } ?></div>
</div>

<?php }else if($locationDO->status == LocationStatus::GRPS_NOT_SUPPORT){?>

<div data-role="content" class="ui-content" role="main">
    <h2 align="center"  style="<?php echo $RESULT_TIPS_DETAIL_STYLE;?>"   > 
        <?php echo $LOCATOR_FAILED_TIPS_BECAUSE_OF_NOT_SUPPORT; ?>
    </h2>
    <div style="text-align:center;">    <?php echo $LOCATING_TIME_TEXT; ?> <?php if($locationDO->locationTime) { echo $locationDO->locationTime->format("Y/m/d H:i:s"); } ?></div>
    <div style="text-align:center;">  <?php echo $SEND_TIME_TEXT; ?> <?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y/m/d H:i:s"); } ?></div>
</div>

<?php } else if($locationDO->status == LocationStatus::WAIT_FOR_CLICK){?>

<div data-role="content" class="ui-content" role="main">
     <h2 align="center"  style="<?php echo $RESULT_TIPS_DETAIL_STYLE;?>" > <?php echo $LOCATOR_WAIT_FOR_CLICK_TIPS; ?></h2>
     <div style="text-align:center;"> 
         <?php echo $SEND_TIME_TEXT; ?> <?php if($locationDO->gmtCreate) { echo $locationDO->gmtCreate->format("Y/m/d H:i:s"); } ?>
     </div>
</div>
<?php } ?>


<?php 
  if($locationDO->status == LocationStatus::GPRS_LOCATION_SUCCESS){
?>
 <script type="text/javascript">
     /**载入文档加载完成*/
     function readyFunction(){
         
          function connectWebViewJavascriptBridge(callback) {
           if (window.WebViewJavascriptBridge) {
                callback(WebViewJavascriptBridge)
            } else {
                document.addEventListener('WebViewJavascriptBridgeReady', function() {
                    callback(WebViewJavascriptBridge)
                }, false)
            }
        }
        
        connectWebViewJavascriptBridge(function(bridge) {
            
            /* Init your app here */
            bridge.init(function(message, responseCallback) {
                if (responseCallback) {
                    responseCallback("JavaScript Response Callback")
                }
             });
           
         
             var tracks = jQuery(".track_success");
            
             if(tracks){
                var track = tracks[0];
                convertToLocationName(jQuery(track).attr("latitude"),
                jQuery(track).attr("longtitude"), placeName);
            }
            
            
            
            
            jQuery(".open_map").click(function(){
                var tracks = jQuery(".track_success");
                if(tracks){
                   var track = tracks[0];
                   var latitude = jQuery(track).attr("latitude");
                   var longtitude = jQuery(track).attr("longtitude");
                    bridge.callHandler("openmap", {"latitude":latitude, "longitude": longtitude, "id":"22"}, function (placeName){
                     if(callback){
                         callback(placeName); 
                      }
                   });
                }
            });
            

            function placeName(placeName){
                 var tracks = jQuery(".track_success");
                 var track = tracks[0];
                 jQuery(track).text(placeName);
            }
           
        
            //convertToLocationName(30.28615719999999, 120.1204291);

            function convertToLocationName(latitude, longtitude, callback){
                var lat = latitude;
                var lng = longtitude;
                bridge.callHandler("geocode", {"latitude":latitude, "longitude": longtitude, "id":"22"}, function (placeName){
                     if(callback){
                         callback(placeName); 
                      }
                });
            }
            
            
            
        });
  
     } 
     
  </script>
 <?php } ?>
  
  