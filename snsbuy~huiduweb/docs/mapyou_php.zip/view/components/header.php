<!DOCTYPE html>
<html class="ui-mobile">
    <head>
        <title> <?php echo $APP_TITLE; ?> </title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, height=device-height">
        <link rel="stylesheet" type="text/css"href="http://lib.sinaapp.com/js/jquery-mobile/1.1.0/jquery.mobile-1.1.0.min.css"/>
        <script type="text/javascript" src="http://lib.sinaapp.com/js/jquery/1.8/jquery.min.js"></script>
        <script type="text/javascript" src="http://lib.sinaapp.com/js/jquery-mobile/1.1.0/jquery.mobile-1.1.0.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                if(window.readyFunction){
                    readyFunction();
                } 
            });
        </script>
        <style>
            .hiddenItem{
                visiblity:hidden;
            }
            .ui-title{
                overflow:visible;
            }
            .ui-header .ui-title{
                 overflow:visible;
                 margin-top: 0.6em;
                 margin-bottom: 0.8em;
                 margin-left: auto;
                 margin-right: auto;
                 overflow: hidden;
            }
        </style>

    </head>
<body class="ui-mobile-viewport ui-overlay-c ui-page ui-body-c ui-page-active">
<div data-role="page" 
     tabindex="0"  style="height: 100%; border: 2px;border-color: red;">

	

    
    
   
        