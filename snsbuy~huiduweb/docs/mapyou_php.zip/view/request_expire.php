<!DOCTYPE html>
<html>
    <head>
         <title><?php echo $REQUEST_EXPORED_TITLE; ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            *{margin:0 auto; padding:0 auto;}
             body { 
                background: #F9F9F9;
                max-width: 600px;
                min-height: 300px;
            }
           .content-font{
                font-size: 20px;
                margin-top: 20px;
            }
            .content-info-div-zh-cn{
                 margin-top: 6px;
                 margin-left: 6px;
                 margin-right: 6px;
                 text-indent:0em; 
                 line-height:120%;
                 font-size: 18px;
                 text-align:justify;   
                 text-justify:inter-ideograph;
            }
            .content-info-div-en-us{
                 margin-top: 6px;
                 margin-left: 6px;
                 margin-right: 6px;
                 text-indent:1em; 
                 line-height:120%;
                 font-size: 18px;
                 text-align:justify;   
                 text-justify:inter-ideograph;
            }
        </style>
    </head>
<body >
    <div id="content" class="content-font">
        <h3  align="center">
            <?php echo $REQUEST_EXPORED_TIPS; ?>
        </h3>
        <div id="content-info-div"  class="<?php echo $LOCATION_TIPS_CLASS_NAME; ?>">
            <?php echo $REQUEST_EXPORED_INFO; ?>
        </div>
    </div>
</body>
</html>