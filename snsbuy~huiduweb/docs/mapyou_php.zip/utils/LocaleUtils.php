<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocaleUtils
 *
 * @author baobao
 */
class LocaleUtils {
    
     private static   $DEFAULT_LANG_CODE = "en_us";

     private static  $RUNTIME_LOCAL = "en_us";
     
     private static $MESSAGE = array(
         "en_us" => array(
             "NotifyMessageSuccess" => "Remote GPS Locating Success",
             "NotifyMessageFailed" => "Remote GPS Locating Failed"
         ),
         "zh_cn" => array(
              "NotifyMessageSuccess"  => "远程定位成功",
              "NotifyMessageFailed" => "远程定位失败"
         )
     );

    /**
     * @var key string 消息key
     */
    public  static final function  getMessage($key){
        $langCode  = LocaleUtils::getLangCode();
         if($langCode == NULL){
             $langCode = self::$DEFAULT_LANG_CODE; 
         }
         
         $bundle =  self::$MESSAGE[$langCode];
         if($bundle == NULL){
             $bundle =  self::$MESSAGE[$DEFAULT_LANG_CODE];
         }
         
         if($bundle != NULL){
             return $bundle[$key];
         }
         return NULL;
    }
    
    /**
     * 返回声音的格式
     */
    public static final function getLangCode(){
        if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ){
            $language = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
            $langcodes = explode(",", $language);

            $countryLang = explode("-", $langcodes[0]);

            $lang = $countryLang[0];
            $country =  $countryLang[1];

            return strtolower($lang)."_".strtolower($country);
       }
       return  self::$DEFAULT_LANG_CODE; 
    }
    
}

/**
 * echo LocaleUtils::getMessage("NotifyMessageSuccess");
 * echo LocaleUtils::getLangCode();
 * 
 */


?>
