<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DateUtils
 *
 * @author baobao
 */
class DateUtils {
    
 /**
  * 比较两个日期，、
  * 
  */
 public static final function compare_date_time($one, $two){
	$m = 0;
	$n = 0;
	if(is_long($one)){
		$m = $one;
	}else{
		$m = strtotime($one);
	}
	if(is_long($two)){
		$n = $two;
	}else{
	   $n = strtotime($two);
	}
    return $m - $n ;
}

/**
 * 返回适合mysql存储的日期格式
 */
public static function currentDateTime(){
    return date("Y-m-d G:i:s", time());
}




}

?>
