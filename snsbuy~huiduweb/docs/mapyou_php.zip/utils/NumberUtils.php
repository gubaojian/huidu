<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NumberUtils
 *
 * @author baobao
 */
class NumberUtils {
    //put your code here
    
 /**
 * 如果$var 在 $min -  $max之间(包括$max)
 * 则返回 $var 否则，
 * 如果$var < $ min返回$min
 * 如果$var > $max  返回 $max;
 * */
public static function middle_num($var, $min, $max){
	if($var >= $min && $var <= $max){
		return $var;
	}
	if($var < $min ){
		return $min;
	}
	return $max;
}





}

?>
