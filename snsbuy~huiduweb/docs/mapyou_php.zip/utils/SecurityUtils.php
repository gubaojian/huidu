<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SecurityUtils
 *
 * @author baobao
 */
class SecurityUtils {

   
    /**
     * 产生指定长度的id， 默认128位长度
     */
    public static final function rand_md5_key($length = 128) {
        $max = ceil($length / 32);
        $random = '';
        for ($i = 0; $i < $max; $i++) {
            $random .= md5(microtime(true) . mt_rand(0, PHP_INT_MAX));
        }
        return substr($random, 0, $length);
    }

    
    /**
     * 默认长度128
     */
    public static final function rand_sha1_key($length = 128) {
        if (!$length) {
            $length = 128;
        }
        $max = ceil($length / 40);
        $random = '';
        for ($i = 0; $i < $max; $i++) {
            $random .= sha1(microtime(true) . mt_rand(0, PHP_INT_MAX));
        }
        return substr($random, 0, $length);
    }

}


//echo SecurityUtils::rand_md5_key(128)."\n";

//echo SecurityUtils::rand_sha1_key(128); 
 
?>
