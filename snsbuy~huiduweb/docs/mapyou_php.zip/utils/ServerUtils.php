<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ServerUtils
 *
 * @author baobao
 */
class ServerUtils {
    
    /**
     * @return string 
     * 返回urk地址
     */
    public static final function getServerHost(){
        if(isset($_SERVER['HTTPS'])  && isset($_SERVER['SERVER_NAME'])){
           return "https://".$_SERVER['SERVER_NAME'];
        }elseif ( isset($_SERVER['SERVER_NAME'])) {
            return 'http://'.$_SERVER['SERVER_NAME'];  
        }
        
    }
    
    /**
     * 返回请求路径，结尾不带/
     */
    public static final function getRequestPath(){
        $path = "";
        if(isset($_SERVER['REQUEST_URI'])){
            $url = $_SERVER['REQUEST_URI'];
            $pos = strripos($url, "/");
           if(isset($pos) && $pos > 0){
               $path =  substr($url, 0, $pos);
           }
        }
        return ServerUtils::getServerHost().$path;
    }
    
    
}
?>
