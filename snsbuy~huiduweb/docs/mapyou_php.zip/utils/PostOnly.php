<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PostOnly
 *
 * @author baobao
 */


if(isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] != 'POST'){
    header( 'Location: '.'http://'.$_SERVER['SERVER_NAME']."/index.php");
    exit(0);
}

?>
