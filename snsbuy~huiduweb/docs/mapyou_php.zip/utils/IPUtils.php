<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IPUtils
 *
 * @author baobao
 */
class IPUtils {
    //put your code here

    /**
     * @var  string
     * @return long
     * ip格式： 127.0.0.1 
     * ip转换成long类型的数
     */
    public static final function toLong($ipAddress) {
        $ipArr = explode('.', $ipAddress);
        $ip = $ipArr[0] * 0x1000000
                + $ipArr[1] * 0x10000
                + $ipArr[2] * 0x100
                + $ipArr[3]
        ;
        return $ip;
    }

    /**
     *  long类型的数转换成ip地址
     */
    public static final function toIp($ipLong) {
        $ipArr = array(0 =>
            floor($ipLong / 0x1000000));
        $ipVint = $ipLong - ($ipArr[0] * 0x1000000); // for clarity
        $ipArr[1] = ($ipVint & 0xFF0000) >> 16;
        $ipArr[2] = ($ipVint & 0xFF00 ) >> 8;
        $ipArr[3] = $ipVint & 0xFF;
        $ipDotted = implode('.', $ipArr);
        return $ipDotted;
    }

    /**
     * 获取请求的ip地址  http://baike.baidu.com/view/9349749.htm
     */
    public static final function getRequestIp() {
        if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
            $cip = $_SERVER["HTTP_CLIENT_IP"];
        } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
            $cip = $_SERVER["HTTP_X_FORWARDED_FOR"];
            $ips = explode(',', $cip);
            $cip = $ips[0];
        } elseif (!empty($_SERVER["REMOTE_ADDR"])) {
            $cip = $_SERVER["REMOTE_ADDR"];
        } else {
            $cip = "0";
        }
        return $cip;
    }

}

/**
  echo IPUtils::toIp("100")."\n";

  $ip = IPUtils::toLong("202.117.4.25");
  echo $ip."\n";
  echo IPUtils::toIp($ip);
 * echo IPUtils::getClientIp();
 */

?>
