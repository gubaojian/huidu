<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of EndBuffer
 *
 * @author baobao
 */
ob_flush();

?>
