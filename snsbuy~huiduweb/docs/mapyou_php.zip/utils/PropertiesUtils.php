<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PropertiesUtils
 *
 * @author baobao
 */
class PropertiesUtils {
    
    public static final function copyProperties($src, $to){
         foreach (get_object_vars($src) as $key => $value) {
            $to->$key = $value;
        }
    }
    
    
}

$from = new stdClass();
$from->test = "ddd";

$to = new stdClass();


PropertiesUtils::copyProperties(from, $to);

print_r($to);




?>
