<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of JSONUtils
 *
 * @author baobao
 */
class JSONUtils {
   
    /**
     * @return array
     */
    public static final function getRequestJSON(){
        
        
        
         $jsonStr = file_get_contents('php://input');
         
       
         
         if(is_null($jsonStr)){
             return  array();
         }
         $json = json_decode($jsonStr);
         return $json;
    }
}

?>
