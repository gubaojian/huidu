<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of JSONServiceUtils
 *
 * @author baobao
 */
class JSONServiceUtils {
    
        /**
         * @var $url     string
         * @var $params  array
         * 添加请求
         */
        public static final function request($url, $params){
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
               
                curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
                $strRes = curl_exec($ch);
                curl_close($ch);
                $arrResponse = json_decode($strRes, true);
                return $arrResponse;
        }
}

?>
