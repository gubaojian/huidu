<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of QueryUtils
 *
 * @author baobao
 */
class QueryUtils {  

    
/**
 *add param to current url
 * */
public static function build_specific_query_from_get_params(){
	 $params = array();
	 $num = func_num_args();
	 for($i=0; $i<$num; $i++){
	 	$name = func_get_arg($i);
	    $value = $_GET[$name];
	    if($value){
	 	     $params[$name] = $value;
	    }
	 }
	 return http_build_query($params);
}

/**
 *add param to current url
 * */
public static final function build_query_from_get_params_on_current_url(){
	 $params = array();
	 $num = func_num_args();
	 for($i=0; $i<$num; $i++){
	 	$name = func_get_arg($i);
	    $value = $_GET[$name];
	    if($value){
	 	     $params[$name] = $value;
	    }
	 }
	 if(count($params) <= 0){
	 	return $_SERVER['SCRIPT_NAME'];
	 }
	 return $_SERVER['SCRIPT_NAME'].'?'.http_build_query($params);
}

/**
 * add param to url
 * */
public static  final function add_param_to_url($url, $param, $value){
	 $data = array();
	 $data[$param] = $value; 
	 if(!strrchr($url, "?")){
	 	return $url.'?'.http_build_query($data);
	 }
	 if(str_ends_with($url, "&")){
	 	 return  $url.http_build_query($data);
	 }else{
	 	 return  $url.'&'.http_build_query($data);
	 } 
}



    
    
    
    
}

?>
