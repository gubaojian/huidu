<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BufferUtils
 *
 * @author baobao
 */
class BufferUtils {
   
    /**
     *  开始缓存
     */
    public static final function startBuffer(){
        
    }
    
    /**
     * 缓存结束
     */
    public static final function endBuffer(){
       
    }
    
    
}

ob_start("bufferCallBack");
function bufferCallBack($buffer){
    return $buffer;
}

?>
