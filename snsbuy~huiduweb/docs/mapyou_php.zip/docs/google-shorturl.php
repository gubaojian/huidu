<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of google-shorturl
 *
 * @author baobao
 */

/**
 * 1、 google短网址服务
 * https://developers.google.com/url-shortener/v1/getting_started
 * 
 * 2、百度短网址
 * http://dwz.cn  (采用object-c客户端)
 * 
 * 3、google短网址链接object-c客户端
 *  http://code.google.com/p/google-api-objectivec-client/

 * 
 * 4、短网址服务，php实现
 * http://davidwalsh.name/google-url
 * 
 * 短网址服务调研：短网址服务、无论用google还是百度服务器端调用速度都相对很慢，因此将这个网址服务转移到客户端
 * 
 * 
 */


?>
