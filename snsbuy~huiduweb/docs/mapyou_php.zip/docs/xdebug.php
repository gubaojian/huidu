<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of xdebug
 *
 * @author baobao
 */

/**1、php.ini    配置
 *
 xdebug.idekey=netbeans-xdebug
xdebug.remote_host=localhost
xdebug.remote_handler=dbgp
xdebug.remote_port=9000
xdebug.remote_enable=on
xdebug.remote_autostart=on
xdebug.remote_log="/Users/baobao/dev/log/apache2/xdebug.log"
zend_extension="/usr/lib/php/extensions/no-debug-non-zts-20090626/xdebug.so"


 * 
 * 2、服务器模式，可以直接debug，设置环境变量
 * export XDEBUG_CONFIG="idekey=netbeans-xdebug"
 * 
 * 
 * 3、命令行模式（暂时未生效）， 加入参数  -d XDEBUG_SESSION_START=netbeans-xdebug
 * 
 * 
 * 
 * 
 * 
 */


?>
