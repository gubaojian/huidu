<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of localize
 *
 * @author baobao
 */
/**
 * 1、采用php的配置实现， 规定编码必须与下表中的相同
 * http://www.lingoes.cn/zh/translator/langcode.htm
 * http://www.lingoes.net/en/translator/langcode.htm
 * 2、语言国家编码表
 * http://www.science.co.il/language/locale-codes.asp
 * 
 * 3、国家语言编码表
 * http://www.fincher.org/Utilities/CountryLanguageList.shtml
 * 
 * 4、 国家编码
 * http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes
 * 
 * 5、 语言编码http://www.w3.org/WAI/ER/IG/ert/iso639.htm
 */

?>
