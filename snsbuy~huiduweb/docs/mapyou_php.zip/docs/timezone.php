<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of timezone
 *
 * @author baobao
 */


/**
 * 1、时区：http://en.wikipedia.org/wiki/List_of_tz_database_time_zones
 * 
 * 2、采用javascript 实现本地化时间输出： http://blog.serverdensity.com/automatic-timezone-conversion-in-javascript/
 * 
 * 
 */

?>
