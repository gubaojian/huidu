<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of google-map
 *
 * @author baobao
 */

/**
 * 1、坐标和名字转换
 *  https://developers.google.com/maps/documentation/javascript/services?hl=zh-CN
 * 
 * 2、静态地图
 *  https://developers.google.com/maps/documentation/staticmaps/?hl=zh-cn
 *  http://24ways.org/2010/finding-your-way-with-static-maps
 *  静态图片地址构造  {纬度（latitude），经度（longitude）}
 *  http://maps.google.com/maps/api/staticmap?center=30.28615719999999,120.1204291&zoom=12&size=100x100&sensor=false&markers=color:blue%7Clabel:S%7C30.28615719999999,120.1204291
 *  
 * 3、google map入门
 *  https://developers.google.com/maps/documentation/javascript/tutorial?hl=zh-CN
 * 
 */
//
//
//http://stackoverflow.com/questions/3641984/convert-coordinates-to-a-place-name
?>
