<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of google-object-c
 *
 * @author baobao
 */
/**
 * 1、object-c http://google-styleguide.googlecode.com/svn/trunk/objcguide.xml
 * 
 * 2、googel的所有客户端
 * https://developers.google.com/url-shortener/libraries
 * 
 */
?>
