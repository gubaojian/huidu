<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of sae-limit
 *
 * @author baobao
 */

/**
 * 1、sae无效函数： file_exists
 * 
 * 
 */

?>
