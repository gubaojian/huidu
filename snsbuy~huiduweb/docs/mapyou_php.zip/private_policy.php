<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of private_policy
 *
 * @author baobao
 */
include_once dirname(__FILE__).'/framework/assemble.php';

?>
