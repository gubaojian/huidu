<?php
include_once dirname(__FILE__).'/utils/PostOnly.php';
include_once dirname(__FILE__).'/lib/hessian/HessianService.php';
include_once dirname(__FILE__).'/service/TrackLocationService.php';

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hello
 *
 * @author baobao
 */
$service = new HessianService(new TrackLocationService());
$service->handle();

?>
