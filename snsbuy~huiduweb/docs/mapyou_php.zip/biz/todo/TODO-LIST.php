<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TODO-LIST
 *
 * @author baobao
 */

/**
 * 1、trakc_location表中数据库增加key字段，代替id, `track_key` VARCHAR(128) NULL ,
 * 2、track_location表中增加accuracy字段， 类型 int
 *    (ALTER TABLE `track_location`.`track_location` ADD COLUMN `accuracy` TINYINT UNSIGNED NULL  AFTER `tr)
 * 3、ALTER TABLE  `track_location` ADD  `device_token` VARCHAR( 64 ) NULL COMMENT  '设备token' AFTER  `track_uuid` ,
ADD  `detail_key` VARCHAR( 128 ) NULL COMMENT  '详情页查看key' AFTER  `device_token`
 * 
 */


?>
