<?php
include_once("saeapns.class.php");
 
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PushNotifyNotification
 *
 * 
 * @author baobao
 */

class PushNotifyNotification{
    
      /**
       *  @var $deviceToken string 设备令牌
       *  @var $message  string  本地通知消息
       *  @return bool
       */
      public static final function sendNotify($deviceToken, $message){
            /* int $cert_id  许可证序号（1-10）沙箱环境 */
           // $cert_id = 553;
            
            /* int $cert_id  许可证序号（1-10）现实编号 */
           $cert_id = 1674;

            /*
            array $body 消息体（包括消息、提醒声音等等），格式请参考示例和{@link http://developer.apple.com/library/ios/#documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/ApplePushService/ApplePushService.html#//apple_ref/doc/uid/TP40008194-CH100-SW1 Apple官方文档}
            */
            $body = array(
                'aps' => array(
                    'alert' => $message,
                    'badge' => 1,
                    'sound' => 'default'
                    ),
                'others' => array()
            );

            //实例化SaeAPNS
            $apns = new SaeAPNS();

            //推送消息
            $result = $apns->push($cert_id, $body, $deviceToken);
            if($result != false){
                return true;
            }else{
                return false;
            }
      }
      
      
   
}
?>
