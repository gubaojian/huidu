


## 创建用户表

CREATE  TABLE `track_location`.`user` (
  `id` BIGINT UNSIGNED NOT NULL ,
  `user_uuid` VARCHAR(72) NULL ,
  `user_key` VARCHAR(128) NULL ,
  `gmt_create` DATETIME NULL ,
  `register_ip` BIGINT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `login_check` (`user_uuid` ASC, `user_key` ASC) );

##  创建操作限制表

CREATE  TABLE `track_location`.`operate_limit` (
  `id` BIGINT UNSIGNED NOT NULL ,
  `user_id` bigint NULL ,
  `operate_ip` bigint NULL ,
  `operate_time` DATETIME NULL ,
  `type` INT NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `operate_check` (`operate_ip` ASC, `operate_time` ASC,`user_id` ASC) );


CREATE  TABLE `track_location`.`track_location` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `user_id` BIGINT NULL ,
  `track_uuid` VARCHAR(72) NULL ,
  `track_key` VARCHAR(128) NULL ,
  `latitude` DOUBLE NULL ,
  `longitude` DOUBLE NULL ,
  `ip_desc` VARCHAR(64) NULL ,
  `viewer_ip` BIGINT NULL ,
  `location_time` DATETIME NULL ,
  `whois_ip` VARCHAR(256) NULL ,
  `status` TINYINT NULL ,
  `mode_type` TINYINT NULL ,
  `redirect_url` VARCHAR(1024) NULL ,
  `gmt_create` DATETIME NULL ,
  `last_modify` DATETIME NULL ,
  PRIMARY KEY (`id`) ,
  INDEX `query_index` (`user_id` ASC, `track_uuid` ASC, `id` ASC) );

