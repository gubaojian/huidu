<?php
include_once dirname(__FILE__).'/../../outlet/Outlet.php';
include_once dirname(__FILE__).'/../../outlet/OutletMapper.php';
include_once dirname(__FILE__).'/../../outlet/Collection.php';
include_once dirname(__FILE__).'/../../outlet/NestedSetBrowser.php';
include_once dirname(__FILE__).'/../../outlet/OutletCollection.php';
include_once dirname(__FILE__).'/../../outlet/OutletConfig.php';
include_once dirname(__FILE__).'/../../outlet/OutletProxy.php';
include_once dirname(__FILE__).'/../../outlet/OutletProxyGenerator.php';
include_once dirname(__FILE__).'/../../outlet/OutletQuery.php';
include_once dirname(__FILE__).'/../domain/Domain.php'; 
include_once dirname(__FILE__).'/outlet-proxies.php';
include_once dirname(__FILE__).'/runtime-config.php';




/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of outlet-config
 *
 * @author baobao
 */


$dev = array(
    
    /** 开发模式
    'connection' => array(
    'dsn'      => 'mysql:host=127.0.0.1;dbname=track_location',
    'username' => 'tracklocation',
    'password' => 'tracklocation123',
    'dialect' => 'mysql'
    ) 
     */ 
    
    /** 线上配置*/
    'connection' => array(
    'dsn'      => 'mysql:host='.SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT.';dbname='.SAE_MYSQL_DB,
    'username' => SAE_MYSQL_USER,
    'password' => SAE_MYSQL_PASS,
    'dialect' => 'mysql'
    ) 
     
   ,
  'classes' => array(
    // User 用户信息映射
    "UserDO" => array(
      'table' => 'user',
      'props' => array(
        'id'        => array('id', 'bigint', array('pk'=>true, 'autoIncrement'=>true)),
        'uuid'      => array('user_uuid', 'varchar'),
        'key'      => array('user_key', 'varchar'),
        'gmtCreate'      => array('gmt_create', 'datetime'),
        'registerIp'      => array('register_ip', 'bigint')
      )
    ),
     // 操作限制信息映射
    'OperateLimitDO' => array(
      'table' => 'operate_limit',
      'props' => array(
        'id'        => array('id', 'bigint', array('pk'=>true, 'autoIncrement'=>true)),
        'userId'     => array('user_id', 'bigint'),
        'operateIp' => array('operate_ip', 'bigint'),
        'operateTime' =>  array("operate_time", "datetime"),
        'type' => array('type', 'tinyint')
      )),
     // 地理位置信息映射
    'LocationDO' => array(
      'table' => 'track_location',
      'props' => array(
        'id'        => array('id', 'bigint', array('pk'=>true, 'autoIncrement'=>true)),
        'userId' => array('user_id', 'bigint'),
        'trackUuid' => array('track_uuid', 'varchar'),
        'trackKey' =>array('track_key', 'varchar'),
        'detailKey' =>array('detail_key', 'varchar'), 
        'deviceToken' =>array('device_token', 'varchar'),
        'latitude' => array('latitude', 'double'),
        'longitude' => array('longitude', 'double'),
        'accuracy' =>  array('accuracy', 'tinyint'),
        'ipDesc' => array('ip_desc', 'varchar'),
        'viewerIp' => array('viewer_ip', 'bigint'),
        'locationTime' => array('location_time', 'datetime'),
        'whoisIp' => array('whois_ip', 'varchar'),
        'status' => array('status', 'tinyint'),
        'modeType' => array('mode_type', 'tinyint'),
        'redirectUrl' =>array('redirect_url', "varchar"),
        'gmtCreate'      => array('gmt_create', 'datetime'),
        'lastModify'      => array('last_modify', 'datetime')
      ))
      
  )
    
    
);

// 可以设置
Outlet::init($dev);

##echo "init OutLet success".get_include_path();

/**
 * 产生代理文件

 
$gen = new OutletProxyGenerator(Outlet::getInstance()->getConfig());

$s = "<?php\n";
$s .= $gen->generate();

file_put_contents(dirname(__FILE__).'/outlet-proxies.php', $s);

 * 
 */ 

##echo  dirname(__FILE__);

?>
