<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of runtime-config
 *
 * @author baobao
 */
/** 设置时区 */
date_default_timezone_set("PRC");




ini_set('display_errors',1); 
error_reporting(E_ALL);

//set_error_handler("logException");


/**
 * var $e Exception
 */
function logException($errorNum, $errstr, $errfile, $errline){
   $s = $errorNum."  ".$errstr."   ".$errfile."    ".$errline;
   //echo $s;
   //file_put_contents(dirname(__FILE__).'/error-exception.php', $s); 
}





?>
