<?php
class UserDO_OutletProxy extends UserDO implements OutletProxy { 
  static $_outlet; 
} 
class OperateLimitDO_OutletProxy extends OperateLimitDO implements OutletProxy { 
  static $_outlet; 
} 
class LocationDO_OutletProxy extends LocationDO implements OutletProxy { 
  static $_outlet; 
} 
