<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OperateLimitType
 *
 * @author baobao
 */
class OperateLimitType {
    
    /**
     * 注册限制
     */
    const  REGISTER = 0;
    
    
    /**
     * 定位条数限制
     */
     const TRACK_TIMES_LIMIT = 2;
    
    
    
}

?>
