<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocationStatusConstant
 * 描述GRPS的定位状态
 * @author baobao
 */
class LocationStatus{
    
    /**
     *  删除的状态
     */
    const  DELETED = -1;
    
    /**
     *  初始化的状态
     */
    const  INIT_STATUS = 0;
    
    /**
     * 信息发送出去的状态, 等待对方点击
     */
    const WAIT_FOR_CLICK  = 2;
    
    /**
     * 对方点击，设备支持gprs定位，但不允许定位
     */
    const GRPS_NOT_ALLOW = 4;
    
    /**
     * 对方点击，但设备不支持gprs定位
     */
    const GRPS_NOT_SUPPORT = 5;
    
    /**
     *  对方点击，且设备支持GRPS，并允许定位，定位成功。
     */
    const  GPRS_LOCATION_SUCCESS = 8;
    
    
    /**
     *  定位超时、未知原因等
     */
    const GPRS_LOCATION_TIMEOUT = 12;
    
    
}

?>
