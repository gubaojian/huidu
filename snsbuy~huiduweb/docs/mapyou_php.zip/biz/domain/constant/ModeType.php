<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ModeType
 *
 * @author baobao
 */
class ModeType {
    
    /**
     * 简单模式
     */
    const SIMPLE_MODE = 0 ;
    
    
    /**
     * 掩饰模式
     */
    const HIDE_MODE = 1; 
    
}

?>
