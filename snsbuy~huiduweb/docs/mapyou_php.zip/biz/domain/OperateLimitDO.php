<?php
include_once dirname(__FILE__).'/constant/OperateLimitType.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LoginDO
 * 用户登陆信息以及注册的信息，注册失败id userId为空
 * @author baobao
 */
class OperateLimitDO {
    
    const CLASS_NAME = "OperateLimitDO";

    /**
     * 登陆id
     */
    public $id;
    
    /**
     * 用户的id
     */
    public $userId;
    
     /**
     * 登陆的ip
     */
    public $operateIp;
    
    
    /**
     * 当天首次登陆时间
     */
    public $operateTime;
    
    
    /**
     * 类型, 0 代表正常登陆类型， 1 代表注册
     */
    public $type;
    
    
    
    
    
    
    
    
}

?>
