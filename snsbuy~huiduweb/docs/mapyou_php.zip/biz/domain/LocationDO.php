<?php
include_once dirname(__FILE__).'/constant/LocationStatus.php';
include_once dirname(__FILE__).'/constant/ModeType.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocationDO
 *
 * @author baobao
 */
class LocationDO {
    
    const  CLASS_NAME = "LocationDO";

    /**
     * 数据库表示符号
     */
    public  $id;
    
    /**
     * 用户的表示符
     */
    public $userId;
    
 
    /**
     * 跟踪全局的id， 对外开放的， 跟踪url链接采用这个uuid表示
     */
    public $trackUuid;
    
    /**
     * 全局跟踪的key
     */
    public $trackKey;
    
    /**
     *  定位详情查看的key， 备用
     */
    public $detailKey;
    
    /**
     * 设备token，用语消息推送
     */
    public $deviceToken;
    
    
    /**
     * 地理位置 gprs latitude
     */
    public $latitude;
    
    /**
     * 地理位置 gprs longitude
     */
    public $longitude;
    
    /**
     * var accuracy int
     * 定位精度
     */
    public $accuracy;
    
    /**
     * 定位时间
     */
    public $locationTime;
            
            
    
    /**
     *  ip地址
     */
    public  $viewerIp;  
    
    /**
     * ip 的地址描述, whois  地址获取
     */
     public $ipDesc;
     
     /**
      * ip 地址的whose描述
      */
     public $whoisIp;
     
     /**
      * 状态 0 初始化    2  消息  发送出去，等待对方点击   
      * 4  对方点击设备支持gprs但拒绝gprs定位 
      * 8  对方点击，支持grps定位允许grps定位  
      * 5  对方设备不支持gprs  
      */
     public $status;
     
     /**
      * 模式类型
      */
     public $modeType;
     
     
     /**
      * 跳转到的url
      */
     public $redirectUrl;
     
     /**
      *  创建时间
      */
     public $gmtCreate;
     
     /**
      * 修改时间
      */
     public $lastModify;
     
     
     
     
     
     
}

?>
