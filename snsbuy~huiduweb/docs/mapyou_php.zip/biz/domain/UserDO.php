<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserDO
 *
 * @author baobao
 */
class UserDO{
    const  CLASS_NAME = "UserDO";
    /**
     *  统一表示符号
     */
    public   $uuid;
    /**
     * 数据库id
     */
    public   $id;
    
    /**
     * key
     */
    public   $key;
    
    /**
     * 创建时间
     */
    public $gmtCreate;
    
    /**
     * 注册的ip
     */
    public $registerIp;
    
   
    
    
    
}

?>
