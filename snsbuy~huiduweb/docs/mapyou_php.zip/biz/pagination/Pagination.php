<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Pagination
 *
 * @author baobao
 */
class Pagination {
    
    /**
     * $var int
     * 总记录数
     */
    private $totalRecord;
    
    
    /**
     * @var int
     * 分页大小
     */
    private  $pageSize = 10;
    
    
    /**
     * @var int
     * 当前页
     */
    private $currentPage;
    
    
    /**
     * 总页数
     */
    private $totalPage = PHP_INT_MAX;
    
    
    
    public function setTotalRecord($totalRecord){
        $this->totalRecord = $totalRecord;
        if(($this->totalRecord % $this->pageSize) == 0){
            $this->totalPage = intval($totalRecord/$this->getPageSize());
        }else{
           $this->totalPage = intval( $totalRecord/$this->getPageSize())  + 1; 
        }
    }
    
    public function getTotalRecord(){
        return $this->totalRecord;
    }
    
    
    public function setPageSize($pageSize){
        if($pageSize > 0){
             $this->pageSize = $pageSize; 
        }
    }
    
    public function getPageSize(){
        return $this->pageSize;
    }
    
    
    public function getCurrentPage(){
        return $this->currentPage;
    }
    
    public function setCurrentPage($currentPage){
        if($currentPage <= 0 ){
           $currentPage = 1;
        }
        if($currentPage > $this->totalPage){
            $currentPage = $this->totalPage;
        }
        $this->currentPage = $currentPage;
    }
    
    public function getTotalPage(){
        return $this->totalPage ;
    }
    
    public function setTotalPage($totalPage){
        return $this->totalPage = $totalPage ;
    }
    
    
    public function getStartRow(){
        return  $this->getPageSize() *($this->getCurrentPage() - 1);
    }
    
}

?>
