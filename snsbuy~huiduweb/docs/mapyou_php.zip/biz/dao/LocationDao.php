<?php
include_once dirname(__FILE__).'/../domain/LocationDO.php';
include_once dirname(__FILE__).'/../query/LocationDOQuery.php';
include_once dirname(__FILE__).'/../config/outlet-config.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocationDao
 *
 * @author baobao
 */
class LocationDao {
   
    /**
     * @var $locationDO LocationDO
     * @return int
     */
    public static function saveLocationDO($locationDO){
        $db = Outlet::getInstance();
   
        
        $db->save($locationDO);
        
        return $locationDO->id;
    }
    
     /**
     * @var $id long 
     * @return LocationDO
     */
    public static function getLocationDOById($id){
        $db = Outlet::getInstance();
        return $db->load(LocationDO::CLASS_NAME, $id);
    }
    
    
     /**
     * @var $trackUuid string
     * @return LocationDO
     */
    public static function getLocationDOByTrackUuid($trackUuid){
        $db = Outlet::getInstance();
        return $db->selectOne(LocationDO::CLASS_NAME, "where track_uuid = ?" , array($trackUuid));
    }
    
    /**
     * @var $locationDOQuery LocationDOQuery
     * @return array LocationDO
     * 根据查询条件，查询输出结果
     */
    public static function findLocationDOListByQuery($locationDOQuery){
        $db = Outlet::getInstance();
        $query = "where true ";
        
        $dynamic = LocationDao::initDynamicStmt($query, $locationDOQuery);
        $query = $dynamic[0];
        $params = $dynamic[1];
        return $db->select(LocationDO::CLASS_NAME, $query, $params); 
    }
    
    /**
     * @var $locationDOQuery LocationDOQuery
     * @return array LocationDO
     * 根据查询条件，查询输出结果
     */
    public static function countAllLocationDOByQuery($locationDOQuery){
        $db = Outlet::getInstance();
        $query = "select count(id) from track_location where true ";
        
        $dynamic = LocationDao::initDynamicStmt($query, $locationDOQuery);
        $query = $dynamic[0];
        $params = $dynamic[1];
        
        $countStmt = $db->query($query, $params);
        return $countStmt->fetchColumn();
    }
    
    
    /**
     * @var $query string
     * @var $operateLimitDOQuery OperateLimitDOQuery
     * @return array  [0]  query   [1]  params
     *  初始化动态查询条件
     */
    private static function initDynamicStmt($query, $locationDOQuery){
        $params = array();
        $index = 0;
        if(isset($locationDOQuery->trackUuid)){
            $query = $query." and track_uuid = ? ";
            $params[$index] = $locationDOQuery->trackUuid;
            $index++;
        }
        
        if(isset($locationDOQuery->trackKey)){
            $query = $query." and track_key = ? ";
            $params[$index] = $locationDOQuery->trackKey;
            $index++;
        }
        
        if(isset($locationDOQuery->userId)){
            $query = $query." and  user_id = ? ";
            $params[$index] = $locationDOQuery->userId;
            $index++;
        }
        
        if(isset($locationDOQuery->id)){
            $query = $query." and  id = ? ";
            $params[$index] = $locationDOQuery->id;
            $index++;
            
        }
        
        if(isset($locationDOQuery->gmtCreateStart)){
            $query = $query." and  gmt_create >=  ? ";
            $params[$index] = $locationDOQuery->gmtCreateStart->format("Y-m-d H:i:s");;
            $index++;
            
        }
        
        if(isset($locationDOQuery->statusList) && count($locationDOQuery->statusList)  > 0){
            $query = $query." and  status in  ( ";
            foreach($locationDOQuery->statusList as $status){
                $query = $query." ?, ";
                $params[$index]  = $status;
                $index++;
            }
            $query = substr( $query,  0, strlen($query) - strlen(strrchr($query, ",")));
            $query = $query." ) ";
        }
        
        //default order by
        $query = $query."   order by id desc ";
        
        if(isset($locationDOQuery->pagination)){
            $query = $query." limit ".  intval($locationDOQuery->pagination->getStartRow())." , ".intval($locationDOQuery->pagination->getPageSize());
        }
        
       
      
        
        return array($query, $params); 
        
    }
    
    
    
    
    
}

?>
