<?php
include_once dirname(__FILE__).'/../domain/UserDO.php';
include_once dirname(__FILE__).'/../config/outlet-config.php';

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserDao
 *
 * @author baobao
 */
class UserDao{
    
    
     /* @var $user UserDO， 根据id查询 */
     public static  function getUserDOById($id){
         $db = Outlet::getInstance();
         return $db->load(UserDO::CLASS_NAME, $id);
     }
    
    
     /** 
      * @var $user UserDO
      * @return UserDO
      * 根据uuid查询 
      */
    public static function getUserDOByUuid($uuid){
        $db = Outlet::getInstance();
        return $db->selectOne(UserDO::CLASS_NAME, "where user_uuid = ?", array($uuid));
    }
    
    /**
     * @var $userDO UserDO
     * 必须选取的上下文对象，才会更想上下文对象。
     */
    public static function  saveUserDO($userDO){
        $db = Outlet::getInstance();
        
        $db->save($userDO);
        return $userDO->id;
    }
    
    
    
    
}



?>
