<?php
include_once dirname(__FILE__).'/../domain/OperateLimitDO.php';
include_once dirname(__FILE__).'/../query/OperateLimitDOQuery.php';
include_once dirname(__FILE__).'/../config/outlet-config.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OperateLimitDao
 *
 * @author baobao
 */
class OperateLimitDao {
  
    
    
    /**
     * @var $operateLimitDO OperateLimitDO
     */
    public static function saveOperateDO($operateLimitDO ){
        $db  = Outlet::getInstance();
        $db->save($operateLimitDO);
        return $operateLimitDO->id;
    }
    
    /**
     * @var $operateLimitDOQuery OperateLimitDOQuery
     */
    public static function findOperateDOListByQuery($operateLimitDOQuery){
        $db  = Outlet::getInstance();
        $query = "where true ";
        
        $dynamic = OperateLimitDao::initDynamicStmt($query, $operateLimitDOQuery);
        $query = $dynamic[0];
        $params = $dynamic[1];
        
        return $db->select(OperateLimitDO::CLASS_NAME, $query, $params); 
    }
    
    
     /**
     * @var $operateLimitDOQuery OperateLimitDOQuery
     */
    public static function countOperateDOByQuery($operateLimitDOQuery){
        $db  = Outlet::getInstance();
        $query = "select count(id) from operate_limit where true ";
        
        $dynamic = OperateLimitDao::initDynamicStmt($query, $operateLimitDOQuery);
        $query = $dynamic[0];
        $params = $dynamic[1];
        
        $countStmt = $db->query($query, $params);
        return $countStmt->fetchColumn();
    }
   
    
    /**
     * @var $query string
     * @var $operateLimitDOQuery OperateLimitDOQuery
     * @return array  [0]  query   [1]  params
     *  初始化动态查询条件
     */
    private static function initDynamicStmt($query, $operateLimitDOQuery){
        $params = array();
        $index = 0;
        
        if(isset($operateLimitDOQuery->operateIpEnd)){
            $query = $query." and operate_ip <= ? ";
            $params[$index] = $operateLimitDOQuery->operateIpEnd;
            $index++;
        }
        
        if(isset($operateLimitDOQuery->operateIpStart)){
            $query = $query." and  operate_ip >= ? ";
            $params[$index] = $operateLimitDOQuery->operateIpStart;
            $index++;
        }
        
        if(isset($operateLimitDOQuery->type)){
            $query = $query." and  type = ? ";
            $params[$index] = $operateLimitDOQuery->type;
            $index++; 
        }
        
        if(isset($operateLimitDOQuery->operateTimeStart)){
            $query = $query." and  operate_time >=  ?";
            $params[$index] = $operateLimitDOQuery->operateTimeStart->format("Y-m-d H:i:s");
            $index++;   
        }
        
        if(isset($operateLimitDOQuery->operateTimeEnd)){
            $query = $query." and  operate_time <=  ?";
            $params[$index] = $operateLimitDOQuery->operateTimeEnd->format("Y-m-d H:i:s");
            $index++;
        }
        
        if(isset($operateLimitDOQuery->userId)){
            $query = $query." and  user_id =  ?";
            $params[$index] = $operateLimitDOQuery->userId;
            $index++;
        }
        
        return array($query, $params); 
    }
    
}

?>
