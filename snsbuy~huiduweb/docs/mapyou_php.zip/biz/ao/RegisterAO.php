<?php
include_once dirname(__FILE__).'/BaseAO.php';
include_once dirname(__FILE__).'/code/RegisterCode.php';
include_once dirname(__FILE__).'/../dao/UserDao.php';
include_once dirname(__FILE__).'/../dao/OperateLimitDao.php';

include_once dirname(__FILE__).'/../../utils/SecurityUtils.php';
include_once dirname(__FILE__).'/../../utils/UUID.php';
include_once dirname(__FILE__).'/../../utils/IPUtils.php';

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegistertAO
 *
 * @author baobao
 */
class RegisterAO extends BaseAO {
    
    /**
     * @var int
     */
    const MAX_REGISTER_TIMES_HOUR = 120;
   
    /**
     * @var $uuid string
     * @var $key string
     * @return Result
     *  检查用户注册， 如果已经注册，则返回uuid以及key，
     *  如果未注册，则检查是否满足注册要求，若满足，则返回注册信息
     * 否则返回对应的提升信息
     */
    public static final function checkRegister($uuid, $key){
       $result = BaseAO::createResult();
       
       //检查参数类型
       if(!is_string($uuid) || !is_string($key)){
           $result->code = RegisterCode::PARAMS_TYPE_NOT_RIGHT;
           $result->message = "params type not right!";
           $result->success = false;
           return $result;
       } 
       
       //检查用户
       $userDO =  UserDao::getUserDOByUuid($uuid);
        
       //用户已注册，并且校验的key正确
       if(isset($key)  && isset($userDO) && ($userDO->key == $key) ){
           $result->code = RegisterCode::SUCCESS;
           $result->message = "user has registered, check success";
           $result->success = true;
           return $result;
       }
       
       //用户未注册, 检查用户注册限制
       $IP_SPACE = 256*6;  //ip地址间隔段
       $TIME_INTERVAL = DateInterval::createFromDateString("1 hours");  //时间间隔
      
       $ipAddress = IPUtils::getRequestIp();
       $ipLong = IPUtils::toLong($ipAddress);
       $currentTimeStart = new DateTime();
       $currentTimeEnd = new DateTime();
            
       $operateLimitDOQuery = new OperateLimitDOQuery();
       $operateLimitDOQuery->type = OperateLimitType::REGISTER;
       $operateLimitDOQuery->operateIpStart = $ipLong - $IP_SPACE;
       $operateLimitDOQuery->operateIpEnd = $ipLong + $IP_SPACE;
       $operateLimitDOQuery->operateTimeStart = $currentTimeStart->sub($TIME_INTERVAL);
       $operateLimitDOQuery->operateTimeEnd = $currentTimeEnd->add($TIME_INTERVAL);
        
     
       
       
       $registerCount = OperateLimitDao::countOperateDOByQuery($operateLimitDOQuery);
       
       
       
       
       if($registerCount > RegisterAO::MAX_REGISTER_TIMES_HOUR){
           $result->code = RegisterCode::AGAINST_REGISTER_LIMIT;
           $result->message = "register busy, please register later!";
           $result->success = false;
           //TODO 记录异常信息, 版本2的功能
           return $result;       
       }else{
             
           $operateLimitDO = new OperateLimitDO();
           $operateLimitDO->operateIp = $ipLong;
           $operateLimitDO->operateTime =   new DateTime();
           $operateLimitDO->type = OperateLimitType::REGISTER;
           
           OperateLimitDao::saveOperateDO($operateLimitDO);
       }
       
 
       
       //注册新用户
       $userDO = new UserDO();
       $userDO->registerIp = $ipLong;
       $userDO->key = SecurityUtils::rand_md5_key();
       $userDO->uuid = UUID::rand_uuid();
       $userDO->registerIp = $ipLong;
       $userDO->gmtCreate = new DateTime();
       
       
       $id = UserDao::saveUserDO($userDO);
       
       $userDO->id = $id;
       //返回注册信息
       $result->result = $userDO;
       $result->code = RegisterCode::SUCCESS;
       $result->message = "register new user and check success!";
       $result->success = true;  
       return $result;  
    }
    
    
    /**
     * 根据用户的id以及key 获取其定位记录的列表
     */
    
    
}


?>
