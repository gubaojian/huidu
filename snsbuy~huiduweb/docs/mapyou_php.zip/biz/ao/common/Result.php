<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Result
 *
 * @author baobao
 */
class Result {
    
    /**
     * @var bool
     */
    public $success;
    
    /**
     * @var string
     */
    public $message;
    
    
    /**
     * @var int
     */
    public $code;
    
    
    /**
     * @var object
     */
    public $result;
    
    
    
    
    
}


//echo get_class(new Result());


?>
