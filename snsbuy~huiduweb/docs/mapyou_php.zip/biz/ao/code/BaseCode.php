<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BaseCode
 *
 * @author baobao
 */
class BaseCode {
     /**
     * 操作执行成功
     */
    const SUCCESS = 0 ;
    
    /**
     * 参数类型不对
     */
    const  PARAMS_TYPE_NOT_RIGHT =  -10;
    
    /**
     * 系统异常
     */
    const SYSTEM_EXCEPTION = -20;
    
    
     /**
     * 用户不存在
     */
    const USER_NOT_EXIST = -30;
    
      /**
     * 用户不存在
     */
    const USER_KEY_NOT_RIGHT = -40;
    
    
    /**
     * 用户未注册
     */
    const USER_NOT_REGISTERED = 10;
    
    
    
    /**
     *  超过规定的跟踪条数
     */
    const AGAINST_MAX_TRACK_TIMES= 30;
    
    
     /**
     * 记录不存在
     */
    const TRACK_RECORD_NOT_EXIST = 40;
    
    
     /**
     * 记录不存在
     */
    const TRACK_UUID_NOT_RIGHT = 50;
    
    /**
     * 记录不存在
     */
    const TRACK_RECORD_STATE_NOT_RIGHT = 60;
    
    
    
    /**
     * 超过注册限制
     */
    const AGAINST_REGISTER_LIMIT = 70;
    
    
     /**
     *  跟踪的key不对
     */
    const TRACK_KEY_NOT_RIGHT = 80;
   
    
    
   
    
    
}

?>
