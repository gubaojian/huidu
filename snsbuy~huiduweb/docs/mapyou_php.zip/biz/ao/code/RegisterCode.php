<?php
include_once dirname(__FILE__).'/BaseCode.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegisterResultCode
 *
 * @author baobao
 */
class RegisterCode  extends BaseCode{
    
    
    
    
    
    
    
    
}

?>
