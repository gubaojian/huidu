<?php
include_once dirname(__FILE__).'/BaseAO.php';
include_once dirname(__FILE__).'/code/TrackLocationCode.php';
include_once dirname(__FILE__).'/../dao/UserDao.php';
include_once dirname(__FILE__).'/../dao/LocationDao.php';
include_once dirname(__FILE__).'/../dao/OperateLimitDao.php';

include_once dirname(__FILE__).'/../../utils/UUID.php';
include_once dirname(__FILE__).'/../../utils/IPUtils.php';
include_once dirname(__FILE__).'/../../utils/SecurityUtils.php';
include_once dirname(__FILE__).'/../../utils/LocaleUtils.php';

include_once dirname(__FILE__).'/../../common/DateFormatPattern.php';

include_once dirname(__FILE__)."/../service/PushNotifyNotification.php";

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TrackLocationAO
 *
 * @author baobao
 */
class TrackLocationAO extends BaseAO{
   
    const MAX_TRACK_TIMES_ONE_DAY = 1000;
    const MAX_RECORD_LIST = 30;
    
    /**
     * @var $uuid string
     * @var $key  string
     * var  $deviceToken  string
     * @return Result
     * 
     * 创建初始化的跟踪程序， 根据uuid 以及key 进行创建
     *   存储deviceToken，简化token无效时的消息推送。简化操作。
     */
    public static function createTrack($uuid, $key, $deviceToken, $redirectUrl){
        $result = BaseAO::createResult();
        try{
            if(!is_string($uuid) || !is_string($key)){
                $result->code = TrackLocationCode::PARAMS_TYPE_NOT_RIGHT;
                $result->message = "params type not right";
                $result->success = false;
                return $result;
            }

            $userDO = UserDao::getUserDOByUuid($uuid);
            if(!isset($userDO)){
                $result->code = TrackLocationCode::USER_NOT_REGISTERED;
                $result->message = "user not registered!";
                $result->success = false;
                return $result;
            }

            if($key != $userDO->key){
              $result->code = TrackLocationCode::USER_KEY_NOT_RIGHT;
              $result->message = "user's key not right";
              $result->success = false;
              return $result;
            }

            //检查限制
            $operateTimeStart = new DateTime();
            $operateTimeEnd = new DateTime();

            $operateLimitDOQuery = new OperateLimitDOQuery();
            $operateLimitDOQuery->type = OperateLimitType::TRACK_TIMES_LIMIT;
            $operateLimitDOQuery->userId = $userDO->id;
            $operateLimitDOQuery->operateTimeStart = $operateTimeStart->setTime(0, 0, 0);   
            $operateLimitDOQuery->operateTimeEnd = $operateTimeEnd;
            try{
                $trackTimes = OperateLimitDao::countOperateDOByQuery($operateLimitDOQuery);
            }  catch (Exception $e){
                 $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
                 $result->message = $e->message;
                 $result->exception = $e;
                 return $result; 
            }
            if($trackTimes > TrackLocationAO::MAX_TRACK_TIMES_ONE_DAY){
                $result->code = TrackLocationCode::AGAINST_MAX_TRACK_TIMES;
                $result->message = "track busy, please tommorrow! ";
                $result->success = false;
                return $result;
            }else{
                $operateLimitDO = new OperateLimitDO();
                $operateLimitDO->operateIp =  IPUtils::toLong(IPUtils::getRequestIp());
                $operateLimitDO->operateTime =   new DateTime();
                $operateLimitDO->type = OperateLimitType::TRACK_TIMES_LIMIT;
                $operateLimitDO->userId = $userDO->id;
                OperateLimitDao::saveOperateDO($operateLimitDO);
            }

            $locationDO  = new LocationDO();
            $locationDO->modeType = 0;
            $locationDO->userId =$userDO->id;
            $locationDO->deviceToken = $deviceToken;
            $locationDO->trackUuid = UUID::rand_uuid();
            $locationDO->trackKey = SecurityUtils::rand_sha1_key();
            $locationDO->detailKey = SecurityUtils::rand_sha1_key();
            $locationDO->status = LocationStatus::INIT_STATUS;
            $locationDO->redirectUrl = $redirectUrl;
            $locationDO->gmtCreate = new DateTime();

            $id = LocationDao::saveLocationDO($locationDO);
            $locationDO->id = $id;



            $result->result = $locationDO;
            $result->code = TrackLocationCode::SUCCESS;
            $result->message = "create track record  success!";
            $result->success = true;  
            return $result;   
        }  catch (Exception $e){
            $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
            $result->message = $e->getMessage();
            $result->exception = $e;
            return $result;
        }
       
    }
    
    
    /**
     * @var $id   long
     * @var $trackUuid  string
     * @return Result
     * 删除初始化的记录
     */
    public static function deleteInitedRecord($trackUuid, $trackKey){
         $result = BaseAO::createResult();
         try{
            if(!is_string($trackUuid) || !is_string($trackKey)){
                $result->code = TrackLocationCode::PARAMS_TYPE_NOT_RIGHT;
                $result->message = "params type not right";
                $result->success = false;
                return $result;
            }

            
            $locationDO = LocationDao::getLocationDOByTrackUuid($trackUuid);
           
            if(!isset($locationDO)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track record not exist!";
                $result->success = false;
                return $result;
            }

            if($trackKey != $locationDO->trackKey){
                $result->code = TrackLocationCode::TRACK_UUID_NOT_RIGHT;
                $result->message = "track key not right";
                $result->success = false;
                return $result;
            }

            if(LocationStatus::INIT_STATUS != $locationDO->status){
                $result->code = TrackLocationCode::TRACK_RECORD_STATE_NOT_RIGHT;
                $result->message = "track state not right";
                $result->success = false;
                return $result;
            }
 
            $locationDO->status = LocationStatus::DELETED;
            $locationDO->lastModify = new DateTime();

           try{
                LocationDao::saveLocationDO($locationDO);
            }  catch (Exception $e){
                 $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
                 $result->message = $e->message;
                 $result->exception = $e;
                 return $result; 
            }
             
            $result->code = TrackLocationCode::SUCCESS;
            $result->message = "delete track record  success!";
            $result->success = true; 
            return $result; 
         }  catch (Exception $e){
              $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
              $result->message = $e->getMessage();
              $result->exception = $e;
              return $result; 
         }
    }
    
    
    
    /**
     * @var $id   long
     * @var $trackUuid  string
     * @return Result
     * 更新状态
     */
    public static function enableTrackRecord($trackUuid, $trackKey){
         $result = BaseAO::createResult();
         if(!is_string($trackKey) || !is_string($trackUuid)){
            $result->code = TrackLocationCode::PARAMS_TYPE_NOT_RIGHT;
            $result->message = "params type not right";
            $result->success = false;
            return $result;
        }
        
        $locationDO = LocationDao::getLocationDOByTrackUuid($trackUuid);
        if(!isset($locationDO)){
            $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
            $result->message = "track record not exist!";
            $result->success = false;
            return $result;
        }
        
        if($trackKey != $locationDO->trackKey){
            $result->code = TrackLocationCode::TRACK_UUID_NOT_RIGHT;
            $result->message = "track key not right";
            $result->success = false;
            return $result;
        }
        
        if(LocationStatus::INIT_STATUS != $locationDO->status){
            $result->code = TrackLocationCode::TRACK_RECORD_STATE_NOT_RIGHT;
            $result->message = "track state not right";
            $result->success = false;
            return $result;
        }
        
        $locationDO->status = LocationStatus::WAIT_FOR_CLICK;
        $locationDO->lastModify = new DateTime();
        
        LocationDao::saveLocationDO($locationDO);
        
        
       $result->code = TrackLocationCode::SUCCESS;
       $result->message = "enable track record  success!";
       $result->success = true;  
       return $result;  
    }
    
    /**
     * @var $trackUuid   String
     * @return Result
     * 记录存在，并且状态处于等待记录才返回true
     */
    public static  final function checkForTrackRecordByUuid($trackUuid, $trackKey){
        $result = BaseAO::createResult();
        try{
            if(!isset($trackUuid) || !isset($trackKey)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track  uuid is null";
                $result->success = false;
                return $result;
            } 
            
            $locationDO = LocationDao::getLocationDOByTrackUuid($trackUuid);
            if(!isset($locationDO)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track record not exist!";
                $result->success = false;
                return $result;
            }
            
            if(!($locationDO->trackKey == $trackKey)){
                $result->code = TrackLocationCode::TRACK_KEY_NOT_RIGHT;
                $result->message = "track key not right";
                $result->success = false;
                return $result;
                
            }
            
             if(!($locationDO->status  == LocationStatus::WAIT_FOR_CLICK || $locationDO->status == LocationStatus::INIT_STATUS)){
                $result->code = TrackLocationCode::TRACK_RECORD_STATE_NOT_RIGHT;
                $result->message = "track state not right";
                $result->success = false;
                return $result;
            }
          
            
            
            
            $result->success = true;
            $result->code = TrackLocationCode::SUCCESS;
            $result->message = "find  track record by uuid success";
            return $result;
        }catch(Exception $e){
           $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
           $result->message = $e->getMessage();
           $result->exception = $e;
           return $result;   
        }
    }
    
    
    /**
     * @var $locationParam    LocationDO
     * @return Result
     */
    public static  final function recordTrack($locationParam){
        $result = BaseAO::createResult();
        try{
            if(!isset($locationParam->trackUuid)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track record uuid is null";
                $result->success = false;
                return $result;
            }

            $dbLocation = LocationDao::getLocationDOByTrackUuid($locationParam->trackUuid);
            if(!isset($dbLocation)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track record not exist!";
                $result->success = false;
                return $result;
            }

            if($dbLocation->trackKey != $locationParam->trackKey){
                $result->code = TrackLocationCode::TRACK_UUID_NOT_RIGHT;
                $result->message = "track key not right";
                $result->success = false;
                return $result;
            }

            if(!($dbLocation->status  == LocationStatus::WAIT_FOR_CLICK || $dbLocation->status == LocationStatus::INIT_STATUS)){
                $result->code = TrackLocationCode::TRACK_RECORD_STATE_NOT_RIGHT;
                $result->message = "track state not right";
                $result->success = false;
                return $result;
            }


            if(isset($locationParam->latitude)  && isset($locationParam->longitude)){
                $dbLocation->latitude = $locationParam->latitude;
                $dbLocation->longitude = $locationParam->longitude;
                $dbLocation->accuracy = $locationParam->accuracy;
                $dbLocation->status = LocationStatus::GPRS_LOCATION_SUCCESS;
            }else{
                if($locationParam->status == LocationStatus::GRPS_NOT_ALLOW){ //不允许定位
                    $dbLocation->status = LocationStatus::GRPS_NOT_ALLOW; 
                }elseif($locationParam->status == LocationStatus::GRPS_NOT_SUPPORT){ //设备不支持定位
                    $dbLocation->status = LocationStatus::GRPS_NOT_SUPPORT;
                }else{ //定位超时
                     $dbLocation->status = LocationStatus::GPRS_LOCATION_TIMEOUT;
                }
            }
            
            
            $dbLocation->id = $dbLocation->id;
            $dbLocation->viewerIp = IPUtils::toLong(IPUtils::getRequestIp());
            $dbLocation->locationTime = new DateTime();
            $dbLocation->lastModify = new DateTime();
            LocationDao::saveLocationDO($dbLocation);
            
            $result->result = $dbLocation;
            $result->code = TrackLocationCode::SUCCESS;
            $result->message = "record track record  success!";
            $result->success = true;  
            
            //push notifycation
            $message = NULL;
            if($dbLocation->status == LocationStatus::GPRS_LOCATION_SUCCESS){
                $message = LocaleUtils::getMessage("NotifyMessageSuccess");
            }else{
                $message = LocaleUtils::getMessage("NotifyMessageFailed"); 
            }
            
            if(isset($dbLocation->deviceToken) && strlen($dbLocation->deviceToken) > 0){
                $sendSuccess =  PushNotifyNotification::sendNotify($dbLocation->deviceToken, $message);
                if($sendSuccess){
                     $result->message =  $result->message." push notify success";
                }else{
                   $result->message =  $result->message." push notify failed"; 
                }
             }
             
             return $result; 
        }catch(Exception $e){
           $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
           $result->message = $e->getMessage();
           $result->exception = $e;
           return $result;  
        }
    }
    
    
    /**
     * @var $uuid string 
     * @var $key string
     * @return Result array LocationDO
     * 获取列表,   用于列表页展示
     */
    public static final function findTrackLocationList($uuid, $key, $pageNum = 1){
        $result = BaseAO::createResult();
        try{
            if(!is_string($uuid) || !is_string($key) || !is_int($pageNum)){
                $result->code = TrackLocationCode::PARAMS_TYPE_NOT_RIGHT;
                $result->message = "params type not right";
                $result->success = false;
                return $result;
            }
            
            $userDO = UserDao::getUserDOByUuid($uuid);
            if(!isset($userDO) || !isset($userDO->key)){
                $result->code = BaseCode::USER_NOT_EXIST;
                $result->message = " user not exist!";
                $result->success = false;
                return $result;   
            }
            
            if($key != $userDO->key){
                $result->code = BaseCode::USER_KEY_NOT_RIGHT;
                $result->message = " user  key not right";
                $result->success = false;
                return $result;   
            }
            
             $gmtCreateTimeStart = new DateTime();
             $gmtCreateTimeStart->sub(new DateInterval("P60D"));
            
            $locationDOQuery = new LocationDOQuery();
            $locationDOQuery->gmtCreateStart = $gmtCreateTimeStart;
            $locationDOQuery->userId = $userDO->id;
            $locationDOQuery->statusList = array(LocationStatus::GPRS_LOCATION_SUCCESS,
            LocationStatus::GRPS_NOT_ALLOW, LocationStatus::GRPS_NOT_SUPPORT, LocationStatus::GPRS_LOCATION_TIMEOUT, LocationStatus::WAIT_FOR_CLICK);
            
            
            $totalRecord = LocationDao::countAllLocationDOByQuery($locationDOQuery);
            
            $locationDOQuery->pagination = new Pagination();
            $locationDOQuery->pagination->setPageSize(30);
            $locationDOQuery->pagination->setTotalRecord($totalRecord);
            $locationDOQuery->pagination->setCurrentPage($pageNum);
            
            $result->result = $locationDOQuery;
            $result->code = BaseCode::SUCCESS;
            $result->success = true;
            
            if($totalRecord <= 0){
                return $result;
            }
            
            $locationDOList = LocationDao::findLocationDOListByQuery($locationDOQuery);
            $locationDOQuery->result = $locationDOList;
            return $result;
        }catch(Exception $e){
           $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
           $result->message = $e->getMessage();
           $result->exception = $e;
           return $result;  
        }
    }
    
    
    
     /**
     * @var $trackUuid string 
     * @var $trackKey string
     * @return Result LocationDO
     * 获取列表,   用于列表页展示
     */
    public static final function getTrackLocationForDetail($trackUuid, $trackKey){
        $result = BaseAO::createResult();
         try{
            if(!is_string($trackUuid) || !is_string($trackKey)){
                $result->code = TrackLocationCode::PARAMS_TYPE_NOT_RIGHT;
                $result->message = "params type not right";
                $result->success = false;
                return $result;
            }

            $locationDO = LocationDao::getLocationDOByTrackUuid($trackUuid);
           
            if(!isset($locationDO)){
                $result->code = TrackLocationCode::TRACK_RECORD_NOT_EXIST;
                $result->message = "track record not exist!";
                $result->success = false;
                return $result;
            }

            if($trackKey != $locationDO->trackKey){
                $result->code = TrackLocationCode::TRACK_UUID_NOT_RIGHT;
                $result->message = "track key not right";
                $result->success = false;
                return $result;
            }
            if(!($locationDO->status == LocationStatus::GPRS_LOCATION_SUCCESS 
                    || $locationDO->status == LocationStatus::GPRS_LOCATION_TIMEOUT 
                    || $locationDO->status == LocationStatus::GRPS_NOT_ALLOW 
                    || $locationDO->status == LocationStatus::GRPS_NOT_SUPPORT 
                    || $locationDO->status == LocationStatus::WAIT_FOR_CLICK)){
                $result->code = TrackLocationCode::TRACK_RECORD_STATE_NOT_RIGHT;
                $result->message = "track state not right";
                $result->success = false;
                return $result;   
            }
            
            $result->result = $locationDO;
            $result->code = BaseCode::SUCCESS;
            $result->message = "get Location Defail Success!";
            $result->success = true;
            return $result;
         }  catch (Exception $e){
            $result->code = TrackLocationCode::SYSTEM_EXCEPTION;
            $result->message = $e->getMessage();
            $result->exception = $e;
            return $result;     
         } 
    }
    
    
}


?>
