<?php
include_once dirname(__FILE__).'/HelloService.php';

include_once dirname(__FILE__).'/../../../lib/hessian/HessianClient.php';


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of HelloServiceTest
 *
 * @author baobao
 */

class RemoteHelloServcie extends HessianClient implements HelloService{
    
    
    
    
    public function sayHello() {
        parent::sayHello();
    }
}


$service = new HessianClient("http://mapyou.sinaapp.com/Hello.php");


echo $service->sayHello();


?>
