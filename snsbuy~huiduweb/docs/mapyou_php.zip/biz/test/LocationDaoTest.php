<?php
include_once 'TestInclude.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocationDaoTest
 *
 * @author baobao
 */
$locationDO = new LocationDO();
$locationDO->ipDesc = "单元测试";
$locationDO->userId = 32352;



$locationId = LocationDao::saveLocationDO($locationDO);

assert($locationId  > 0);


$locationDO = LocationDao::getLocationDOById($locationId);

$locationDO->viewerIp = 20000;

$locationDO->locationTime = new DateTime();

$locationId = LocationDao::saveLocationDO($locationDO);

assert($locationId  > 0);

$loadFromDB = LocationDao::getLocationDOById($locationId);

assert(!is_null($loadFromDB));

$locationDOQuery = new LocationDOQuery();
$locationDOQuery->id  = $locationId;
$locationDOQueryList = LocationDao::findLocationDOListByQuery($locationDOQuery);

print_r($locationDOQueryList);


?>
