<?php

include_once 'TestInclude.php';

include_once dirname(__FILE__) . '/../../utils/SecurityUtils.php';
include_once dirname(__FILE__) . '/../../utils/UUID.php';
include_once dirname(__FILE__) . '/../../utils/IPUtils.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OperateLimitDaoTest
 *
 * @author baobao
 */
$IP_SPACE = 256 * 6;  //ip地址间隔段
$TIME_INTERVAL = DateInterval::createFromDateString("1 hours");  //时间间隔
$ipAddress = IPUtils::getRequestIp();
$ipLong = IPUtils::toLong($ipAddress);
$currentTimeStart = new DateTime();
$currentTimeEnd = new DateTime();




$operateLimitDO = new OperateLimitDO();


$operateLimitDO->operateIp = $ipLong;
$operateLimitDO->operateTime = new DateTime();
$operateLimitDO->type = 0;


$id = OperateLimitDao::saveOperateDO($operateLimitDO);
assert($id > 0);



$operateLimitDOQuery = new OperateLimitDOQuery();
$operateLimitDOQuery->type = OperateLimitType::REGISTER;
$operateLimitDOQuery->operateIpStart = $ipLong - $IP_SPACE;
$operateLimitDOQuery->operateIpEnd = $ipLong + $IP_SPACE;
$operateLimitDOQuery->operateTimeStart = $currentTimeStart->sub($TIME_INTERVAL);
$operateLimitDOQuery->operateTimeEnd = $currentTimeEnd->add($TIME_INTERVAL);


$operateLimitDOList = OperateLimitDao::findOperateDOListByQuery($operateLimitDOQuery);

assert(count($operateLimitDOList) > 0);

$count = OperateLimitDao::countOperateDOByQuery($operateLimitDOQuery);

assert($count > 0);

echo $count;




?>
