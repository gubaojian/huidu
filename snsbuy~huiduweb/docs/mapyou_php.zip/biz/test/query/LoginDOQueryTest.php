<?php
include_once dirname(__FILE__).'/../TestInclude.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of newPHPClass
 *
 * @author baobao
 */

$loginDOQuery = new LoginDOQuery();

if($loginDOQuery->id){
    
    echo "init id";
}

 $params = array(49, "ddd");
 

 
 echo $params[0];
 
 $params[0] = 101;
 
  echo $params[0];


?>
