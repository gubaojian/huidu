<?php

include_once 'TestInclude.php';



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserDaoTest
 *
 * @author baobao
 */


$userDO = new UserDO();
//$userDO->id = 23;
//$userDO->gmtCreate= new DateTime();
//$userDO->uuid = UUID::rand_uuid();
//$userDO->key = SecurityUtils::rand_md5_key();
$userDO->registerIp = 113252;

$userId = UserDao::saveUserDO($userDO);

assert($userId > 0);
print_r($userDO);
echo "save user ".$userId."\n";;

/* @var $user UserDO */

$id = 20;

//$start = microtime();
//for($i=0; $i<10000; $i++){
  $user = UserDao::getUserDOById(20);
//}
//echo "pk used: ".(microtime() - $start);
assert($user != null);
assert($user->id == $id);
assert($user->key != null);



$user->registerIp = rand(100, 300);

UserDao::saveUserDO($user);

print_r($user);

//$startTwo = time();
//for($i=0; $i<10000; $i++){
   $userTwo = UserDao::getUserDOByUuid($user->uuid);
//}

//echo "index used: ".(time() - $startTwo);


assert($userTwo != null);
assert($user->id == $userTwo->id);
assert($user->key == $userTwo->key);


print_r($userTwo);




 

?>
