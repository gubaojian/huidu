<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TestInclude
 *
 * @author baobao
 */
echo  dirname(__FILE__);

include_once dirname(__FILE__).'/../dao/UserDao.php';
include_once dirname(__FILE__).'/../dao/OperateLimitDao.php';
include_once dirname(__FILE__).'/../dao/LocationDao.php';


include_once dirname(__FILE__).'/../config/outlet-config.php';


echo "import user"."\n";

include_once dirname(__FILE__).'/../../utils/DateUtils.php';

include_once dirname(__FILE__).'/../../utils/UUID.php';

include_once dirname(__FILE__).'/../../utils/SecurityUtils.php';

include_once  dirname(__FILE__).'/../query/OperateLimitDOQuery.php';

echo  dirname(__FILE__);

$config = Outlet::getInstance()->getConfig();

print_r($config->getEntities());
 
/**
 * @var
 */
       


?>
