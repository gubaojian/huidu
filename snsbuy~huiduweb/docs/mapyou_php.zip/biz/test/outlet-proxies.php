<?php
echo $_SERVER['HTTP_HOST'];

echo 'http://'.$_SERVER['SERVER_NAME'];


?>
