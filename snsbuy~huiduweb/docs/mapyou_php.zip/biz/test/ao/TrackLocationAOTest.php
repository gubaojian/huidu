<?php
include_once dirname(__FILE__).'/../../ao/TrackLocationAO.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TrackLocationAOTest
 *
 * @author baobao
 */

$uuid = "87c36376-2e3449b9-ba15dd2b-5e50b71d3264-3f9ba8b438e3c7b642cef9ec64b58ff6";
$key = "670101e4f57a98726a93dd90043944daab98609e89f6b883439f91e629d25ffa2607fdfd8d0ab83f58a8026e3006e0c21af107d293e9ae0ea5d3ef698c7a34e8";

$type = 0;

$createTrack = TrackLocationAO::createTrack($uuid, $key, $type, $redirectUrl);

assert($createTrack->success);
             
echo is_string($createTrack->result->id);

echo "\n".(is_int($createTrack->result->id)).(is_string("hh"));

$enableResult = TrackLocationAO::enableTrackRecord($createTrack->result->trackUuid, $createTrack->result->trackKey);

print_r($enableResult);

assert($enableResult->success);

$locationParam = new LocationDO();

$locationParam->id = $createTrack->result->id;
$locationParam->latitude = 344.33;
$locationParam->longitude = 53523.34;
$locationParam->trackUuid = $createTrack->result->trackUuid;
$locationParam->trackKey = $createTrack->result->trackKey;


$recordResult = TrackLocationAO::recordTrack($locationParam);
      
print_r($recordResult);

assert($recordResult->success);

$deleteResult = TrackLocationAO::deleteInitedRecord($createTrack->result->trackUuid, $createTrack->result->trackKey);

assert(!$deleteResult->success);


$createTrack = TrackLocationAO::createTrack($uuid, $key, $type, $redirectUrl);
$deleteResult = TrackLocationAO::deleteInitedRecord($createTrack->result->trackUuid, $createTrack->result->trackKey);
assert($deleteResult->success);



$listResult = TrackLocationAO::findTrackLocationList($uuid, $key);

assert($listResult ->success);

print_r($listResult);


?>
