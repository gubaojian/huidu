<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
date_default_timezone_set("PRC");
/**
 * Description of DateTimeIntervalTest
 *
 * @author baobao
 */
$date = new Datetime();

$date->sub(new DateInterval("P30D"));

echo $date->format("Y-m-d H:i:s");
?>
