<?php
include_once dirname(__FILE__).'/../../ao/RegisterAO.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegisterAOTest
 *
 * @author baobao
 */
$registerAO = new RegisterAO();

$result = $registerAO->checkRegister("32222", "eee not exist");

print_r($result);

assert($result->result->id > 0);

?>
