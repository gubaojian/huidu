<?php
include_once dirname(__FILE__) . '/../../api/GoogleShortURLApi.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GoogleShortUrlApi
 *
 * @author baobao
 */


$shortUrlApi = new GoogleShortURLApi("AIzaSyCc49n8xlEgVLFf9b0SAf4H7rPG2SaZldo");

for( $i=0; $i<100; $i++){
   $url = $shortUrlApi->shorten("http://www.".$i."google".$i.".com?id=eb882dd4f80437833ec5045454efc41e6e979f0d34a106e4026cd61f9c8033365723ebd4ff984e92eee9ed4928257d676f01a6b4877b5fd64af6d66e9fac4e10".$i);

   echo $url;
}

?>
