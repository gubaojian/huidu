<?php
include_once dirname(__FILE__).'/../../service/TinyUrlService.php';

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TinyUrl
 *
 * @author baobao
 */
$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,"http://dwz.cn/create.php");
curl_setopt($ch,CURLOPT_POST,true);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$data=array('url'=>'http://www.baidu.com/');
curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
$strRes=curl_exec($ch);
curl_close($ch);
$arrResponse=json_decode($strRes,true);
if($arrResponse['status']==0)
{
/**错误处理*/
echo iconv('UTF-8','GBK',$arrResponse['err_msg'])."\n";
}
/** tinyurl */
echo$arrResponse['tinyurl']."\n";

for($i=0; $i<200; $i++){
    $shortUrl = TinyUrlService::getTinyUrl("http://www.".$i."google".$i.".com?id=eb882dd4f80437833ec5045454efc41e6e979f0d34a106e4026cd61f9c8033365723ebd4ff984e92eee9ed4928257d676f01a6b4877b5fd64af6d66e9fac4e10");

   echo $shortUrl;
} 

?>
