<?php
include_once dirname(__FILE__).'/../domain/OperateLimitDO.php';





/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LoginQuery
 *
 * @author baobao
 */
class OperateLimitDOQuery extends OperateLimitDO {
   
    /**
     * 操作ip起始段 
     */
    public $operateIpStart;
    
    /**
     * 操作ip结尾段
     */
    public $operateIpEnd;
    
    /**
     * 登陆时间开始时间段
     */
    public $operateTimeStart;
    
    
    /**
     * 登陆时间结束时间段
     */
    public $operateTimeEnd;
    
    
    
}

?>
