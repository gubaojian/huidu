<?php
include_once dirname(__FILE__).'/../domain/LocationDO.php';
include_once dirname(__FILE__).'/../pagination/Pagination.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of LocationDOQuery
 *
 * @author baobao
 */
class LocationDOQuery  extends LocationDO{
    
    /**
     * @var Pagination
     * 分页信息
     */
    public $pagination;
    
    
    /**
     * @var array
     * 查询结果
     */
    public $result;
    
    /**
     * @var array
     * 状态集合
     */
    public $statusList;
    
    
    /**
     *  @var date
     *  创建的开始时间
     */
    public $gmtCreateStart;
    
    
    
   
}

?>
