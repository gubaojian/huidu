<?php
include_once dirname(__FILE__).'/utils/PostOnly.php';
include_once dirname(__FILE__).'/lib/hessian/HessianService.php';
include_once dirname(__FILE__).'/service/RegisterService.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Hello
 *
 * @author baobao
 */


/**
$uuid = $_POST['uuid'];
$key = $_POST['key'];

$result = RegisterAO::checkRegister($uuid, $key);

echo json_encode($result);
 
 */

$service = new HessianService(new RegisterService());
$service->handle();


?>
