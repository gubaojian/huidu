<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of record-detail
 *
 * @author baobao
 */
include_once dirname(__FILE__).'/framework/assemble.php';
?>
