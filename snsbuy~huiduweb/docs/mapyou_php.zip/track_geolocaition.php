<?php
include_once dirname(__FILE__).'/biz/ao/TrackLocationAO.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of track_geolocaition
 *
 * @author baobao
 */
$accuracy =  isset($_POST['accuracy']) ? $_POST['accuracy'] : '';
$latitude = isset($_POST['latitude']) ?  $_POST['latitude'] : '';
$longitude = isset($_POST['longitude']) ?  $_POST['longitude'] : '';
$trackKey = isset($_POST['trackKey']) ?  $_POST['trackKey'] : '';
$trackUuid = isset($_POST['trackUuid']) ?   $_POST['trackUuid'] : '';
$status = isset($_POST['status']) ?  intval($_POST['status'])  : 12;

if(!isset($trackKey) || !isset($trackUuid)){
    echo "param miss";
    return;
}

$locationParam = new stdClass();
$locationParam->accuracy = $accuracy;
$locationParam->latitude = $latitude;
$locationParam->longitude = $longitude;
$locationParam->trackKey = $trackKey;
$locationParam->trackUuid = $trackUuid; 
$locationParam->status = $status;

$result = TrackLocationAO::recordTrack($locationParam);


//output result
header("Content-Type: text/html; charset=utf-8");
//print_r($result);

if($result->success){
    echo $result->message;
}else{
    echo "failed";
}
?>
