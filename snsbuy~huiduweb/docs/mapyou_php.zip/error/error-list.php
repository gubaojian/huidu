<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of error-list
 *
 * @author baobao
 */


/**
 * 1、Unknown error type: [8] Undefined offset: 2<br />  
 *     原因是使用之前惟做是否赋值的判断，加上下面判断解决问题
 *     isset($f[2]) && isset($f[2]['autoIncrement'])  &&
 * 
 */
    
    

?>
