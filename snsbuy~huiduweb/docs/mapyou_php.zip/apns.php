<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of apns
 *
 * @author baobao
 */


include_once("saeapns.class.php");
 
 
/* int $cert_id  许可证序号（1-10）*/
$cert_id = 1674;
 
/* string $device_token 设备令牌 */
$device_token = '18ee2e9d3bbb3b2773c9d7f432f56403bc91b2f1ab1cd6eca71282b08ab3cd84';
 
/* string $message 消息内容 */                         
$message = "推送测试 from SAE";
 
 
/*
 
array $body 消息体（包括消息、提醒声音等等），格式请参考示例和{@link http://developer.apple.com/library/ios/#documentation/NetworkingInternet/Conceptual/RemoteNotificationsPG/ApplePushService/ApplePushService.html#//apple_ref/doc/uid/TP40008194-CH100-SW1 Apple官方文档}
 
*/
 
 $body = array(
                'aps' => array(
                    'sound' => 'default',
                    'alert' => $message,
                    'badge' => 1
                    ),
               'others' => array()
            );
 

 
//实例化SaeAPNS
 
$apns = new SaeAPNS();
 
//推送消息
 
$result = $apns->push($cert_id, $body, $device_token);

var_dump($result);
 
if ($result !== false) {
 
    echo '发送成功';
     
} else {
  
    echo '发送失败';
    var_dump($apns->errno(), $apns->errmsg());    
}           

?>
