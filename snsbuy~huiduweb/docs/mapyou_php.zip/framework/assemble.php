<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of assemble
 *
 * @author baobao
 */

include_once dirname(__FILE__).'/assemble-config.php';
include_once dirname(__FILE__).'/assemble-all.php';
?>
