<?php
include_once dirname(__FILE__).'/assemble-private-function.php';
include_once dirname(__FILE__).'/assemble-function.php';
include_once dirname(__FILE__).'/assemble-config.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of assemble-all
 *
 * @author baobao
 */


/**
 * 组装module 以及 view
 * 框架程序, 解析程序的相对路径名字
 */
$assemble_temp_request_file_name = $_SERVER['SCRIPT_NAME'];
if(isset($ASSEMBLE_CONTEXT_PATH)){
    if( strpos($assemble_temp_request_file_name, $ASSEMBLE_CONTEXT_PATH) === 0){
       $assemble_temp_request_file_name = substr($assemble_temp_request_file_name, strlen($ASSEMBLE_CONTEXT_PATH)); 
    }else{
        echo "\n request path ".$assemble_temp_request_file_name." not contains context path, please make sure config context path: ".$ASSEMBLE_CONTEXT_PATH." is right.";
        die();
    }
    
}


/**
 * 请求页面的本地化配置， 以及全局本地化配置文件
 */
if(isset($ASSEMBLE_GLOBAL_LOCALE_FILE)){
   $assembleGlobalFile =  private_localize_require_once_file($ASSEMBLE_PRIVATE_FILE_SEPATAROR.$ASSEMBLE_GLOBAL_LOCALE_FILE);
   if(isset($assembleGlobalFile) && file_exists($assembleGlobalFile) && !is_dir($assembleGlobalFile)){
       include_once $assembleGlobalFile;
   }
}



$assemble_temp_localize_file = private_localize_require_once_file($assemble_temp_request_file_name);


if(isset($assemble_temp_localize_file) && file_exists($assemble_temp_localize_file) && !is_dir($assembleGlobalFile)){
   include_once $assemble_temp_localize_file; 
}

/**assemble module*/
$module = $ASSEMBLE_MODULE_DIR.$assemble_temp_request_file_name;




if(file_exists($module)){
   require_once $module;
}

/** assemble view */
//set charset
//
header("Content-Type: text/html; charset=utf-8");

$view = $ASSEMBLE_VIEW_DIR.$assemble_temp_request_file_name;
if(file_exists($view)){
    if(!isset($ASSEMBLE_RUMTIME_NO_HEADER_FOOTER) || !$ASSEMBLE_RUMTIME_NO_HEADER_FOOTER){
        require_once $ASSEMBLE_VIEW_COMPONENTS_DIR."/header.php";
    }
    
    require_once $view;
    if(!isset($ASSEMBLE_RUMTIME_NO_HEADER_FOOTER) || !$ASSEMBLE_RUMTIME_NO_HEADER_FOOTER){
      require_once $ASSEMBLE_VIEW_COMPONENTS_DIR."/footer.php";
    }
}






?>
