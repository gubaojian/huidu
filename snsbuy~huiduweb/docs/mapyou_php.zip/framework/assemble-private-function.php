<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of assemble-function
 *
 * @author baobao
 */
$ASSEMBLE_PRIVATE_FILE_SEPATAROR = "/";

/**内部私有函数, 返回可包含的本地化文件的路径*/
function private_localize_require_once_file($file_name){
    global $ASSEMBLE_PRIVATE_FILE_SEPATAROR;
    global $ASSEMBLE_LOCALIZE_DIR;
    global $ASSEMBLE_DEFAULT_LOCALE_LANG;
    
    if(isset($ASSEMBLE_LOCALIZE_DIR)){
        $localizeFile = $ASSEMBLE_LOCALIZE_DIR.private_localize_file_name($file_name);
         
        if(file_exists($localizeFile)){
             return $localizeFile;
        }else{ 
           // require default  lang config
           if(isset($ASSEMBLE_DEFAULT_LOCALE_LANG)){  //采用默认区域
            $localizeFile = $ASSEMBLE_LOCALIZE_DIR.$ASSEMBLE_PRIVATE_FILE_SEPATAROR.strtolower($ASSEMBLE_DEFAULT_LOCALE_LANG).$file_name;
            if(file_exists($localizeFile)){
                return $localizeFile; 
            }
            }else{
                $localizeFile = $ASSEMBLE_LOCALIZE_DIR.$file_name;
                if(file_exists($localizeFile)){
                    return $localizeFile; 
                }
            } 
        } 
    }
    return NULL;
}





/**
 * 返回本地化的配置文件,  内置函数
 * 请求 /index.php
 * 返回格式 /zh-CN/index.php
 */
function private_localize_file_name($file){
    global $ASSEMBLE_PRIVATE_FILE_SEPATAROR;
    global $ASSEMBLE_RUMTIME_LOCALE;
    global $ASSEMBLE_DEFAULT_LOCALE_LANG;


    if(isset($ASSEMBLE_RUMTIME_LOCALE)){
        return  $ASSEMBLE_PRIVATE_FILE_SEPATAROR.strtolower($ASSEMBLE_RUMTIME_LOCALE).$file;
    }
   
    
    //locale from accept language
    if(isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ){
        $language = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
        $langcodes = explode(",", $language);
        $countryLang = explode("-", $langcodes[0]);
        
        if(isset($countryLang[0])  && isset($countryLang[1])){
              $lang = $countryLang[0];
              $country =  $countryLang[1];
              return $ASSEMBLE_PRIVATE_FILE_SEPATAROR.strtolower(trim($lang))."_".strtolower(trim($country)).$file;
        }
    }
    
    //if not found, get locale from user agent
    if(isset($_SERVER['HTTP_USER_AGENT'])){
        $AGENT = $_SERVER['HTTP_USER_AGENT'];
        $start =  strpos($AGENT, "(");
        $end = strpos($AGENT, ")");
        $subAgent = substr($AGENT, $start + 1, $end - $start - 1);
        $subs = explode(";", $subAgent);
        if(isset($subs[3])){ // lang code 
             $countryLang = explode("-", $subs[3]);
            if(isset($countryLang[0])  && isset($countryLang[1])){
                $lang = $countryLang[0];
                $country =  $countryLang[1];
                return $ASSEMBLE_PRIVATE_FILE_SEPATAROR.strtolower(trim($lang))."_".strtolower(trim($country)).$file;
            }
        }
    }
    
    //found no locale return default locale, 如果没有配置默认的locale报错
    if(isset($ASSEMBLE_DEFAULT_LOCALE_LANG)){
        return $ASSEMBLE_DEFAULT_LOCALE_LANG;
    }else{
        echo "\n find none locale from request and no default is configed ";
        die();
    }
    
}
?>
