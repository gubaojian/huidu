<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of assemble-config
 *
 * @author baobao
 */
$ASSEMBLE_MODULE_DIR = dirname(__FILE__)."/../module";  //模块名称
$ASSEMBLE_VIEW_DIR = dirname(__FILE__)."/../view";   // 视图配置
$ASSEMBLE_VIEW_COMPONENTS_DIR = dirname(__FILE__)."/../view/components"; //自动保护的页头页脚目录
//$ASSEMBLE_CONTEXT_PATH= "";  //程序运行上下文路径

//$ASSEMBLE_CONTEXT_PATH= "/sinaapp/mapyou/1";

/** 附加功能, 本地化, 全局国际化文件采用 global.php处理，配置到array中
 *  用 $ASSEMBLE_RUMTIME_LOCALE 设置运行时默认的local地址， 国家代码一律小写(不同浏览器大小写不统一)
 *  php文件中一律采用 $LOCOLIZE_CONFIG配置 , 文件明不要用特殊字符 - 之类的
 *  */
$ASSEMBLE_LOCALIZE_DIR = dirname(__FILE__)."/../localize";
$ASSEMBLE_DEFAULT_LOCALE_LANG = "en_us";
$ASSEMBLE_GLOBAL_LOCALE_FILE = "global.php";  //相对路径

//配置参数：$ASSEMBLE_RUMTIME_LOCALE ="en_US";   // 设定本地化地点

//运行参数：   $ASSEMBLE_RUMTIME_NO_HEADER_FOOTER = true;  //设定不包含头部和尾部





?>
