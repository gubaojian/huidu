<?php
include_once dirname(__FILE__).'/../biz/ao/RegisterAO.php';
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of RegisterService
 *
 * @author baobao
 */
class RegisterService {
   
     /**
     * @var $uuid   string
     * @var $key  string
     * @return Result
     * 更新状态
     */
    public  function checkRegister($uuid, $key){
        
         try{
           return  RegisterAO::checkRegister($uuid, $key);
         }catch(Exception $e){
             return $e;
         }   
    }
}

?>
