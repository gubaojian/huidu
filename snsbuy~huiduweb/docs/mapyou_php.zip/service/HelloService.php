<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of HelloService
 *
 * @author baobao
 */
class HelloService {
    
    public function  sayHello(){   
        
        return "Hello World";
    }
}

?>
