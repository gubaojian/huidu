<?php
include_once dirname(__FILE__).'/../biz/ao/TrackLocationAO.php';
include_once dirname(__FILE__).'/../biz/api/GoogleShortURLApi.php';
include_once dirname(__FILE__).'/../utils/ServerUtils.php';

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TrackLocationService
 *
 * @author baobao
 */
class TrackLocationService {
    
     /**
     * @var $uuid string
     * @var $key  string
      * @var $id  int
     * @return Result
     * 
     * 创建初始化的跟踪程序， 根据uuid 以及key 进行创建
     *  
     */
      public  function createTrack($uuid, $key, $type, $redirectUrl = NULL){
          try{
             $createResult = TrackLocationAO::createTrack($uuid, $key, $type, $redirectUrl); 
              if(!$createResult->success){
                return $createResult;
              }

             $params = array("trackKey"=>$createResult->result->trackKey,  "trackUuid"=>$createResult->result->trackUuid);
             $url = ServerUtils::getRequestPath()."/map.php?".http_build_query($params);
             
             $createResult->result->redirectUrl = $url;
             return $createResult; 
          }catch(Exception $e){
              return $e;
          }
      }
      
    /**
     * @var $id   long
     * @var $trackUuid  string
     * @return Result
     * 删除初始化的记录
     */
       public function deleteInitedRecord($trackUuid, $trackKey){
         return TrackLocationAO::deleteInitedRecord($trackUuid, $trackKey);
       }
      
    /**
     * @var $id   long
     * @var $trackUuid  string
     * @return Result
     * 更新状态
     */
    public  function enableTrackRecord($trackUuid, $trackKey){
         return TrackLocationAO::enableTrackRecord($trackUuid, $trackKey);
    }
      
      
}

?>
