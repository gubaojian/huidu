/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



     function showMyGeoLocateion(){
          if(navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(function(position){
                 locationLatLng =  new google.maps.LatLng(position.coords.latitude,position.coords.longitude); 
                 map.setCenter(locationLatLng);
                   new google.maps.Marker({
                        position: locationLatLng, 
                        map: map, 
                        title:"title test!"
                    }); 
                 alert("自动定位成功");
              },
              function (error){
                     switch(error.code) 
                    {
                        case error.PERMISSION_DENIED:
                            alert("用户拒绝定位");   
                            break;
                        case error.POSITION_UNAVAILABLE:
                            alert("定位失败");   ;
                            break;
                        case error.TIMEOUT:
                            break;
                        case error.UNKNOWN_ERROR:
                        break;
                    } 
                    alert("定位失败");   ;
              });
          }else{
              alert("浏览器不支持定位");
          }
         
     }