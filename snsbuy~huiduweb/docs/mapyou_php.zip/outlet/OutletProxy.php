<?php
/**
 * Interface that all proxies must implement
 * @package outlet
 */
interface OutletProxy {}