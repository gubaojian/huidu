svn add *.php --quiet
svn add */   --quiet

svn add biz/*.php --quiet

svn add utils/*.php --quiet

svn add error/*.php --quiet





## Unknown error type: [8] Undefined offset: 2<br />   isset($f[2]) && isset($f[2]['autoIncrement'])  &&