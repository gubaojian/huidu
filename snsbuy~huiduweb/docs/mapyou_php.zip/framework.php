<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of framework
 *
 * @author baobao
 */

/** 组装器配置*/
$ASSEMBLE_MODULE_DIR = dirname(__FILE__)."/module";  //模块名称
$ASSEMBLE_VIEW_DIR = dirname(__FILE__)."/view";   // 视图配置
$ASSEMBLE_VIEW_COMPONENTS_DIR = dirname(__FILE__)."/view/components"; //自动保护的页头页脚目录
$ASSEMBLE_CONTEXT_PATH= "/sinaapp/mapyou/1";  //程序运行上下文路径




/**
 * 组装module 以及 view
 * 框架程序
 */
$file_name = $_SERVER['SCRIPT_NAME'];
if(isset($ASSEMBLE_CONTEXT_PATH)){
    $file_name = substr($file_name, strlen($ASSEMBLE_CONTEXT_PATH));
    
}
/**assemble module*/
$module = $ASSEMBLE_MODULE_DIR.$file_name;
if(file_exists($module)){
   require_once $module;
}

/** assemble view */
$view = $ASSEMBLE_VIEW_DIR.$file_name;
if(file_exists($view)){
    require_once $ASSEMBLE_VIEW_COMPONENTS_DIR."/header.php";
    require_once $view;
    require_once $ASSEMBLE_VIEW_COMPONENTS_DIR."/footer.php";
}

?>
