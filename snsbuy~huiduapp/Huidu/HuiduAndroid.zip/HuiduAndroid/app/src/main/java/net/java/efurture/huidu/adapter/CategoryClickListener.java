package net.java.efurture.huidu.adapter;

import net.java.efurture.huidu.domain.Category;
import android.view.View;

public interface CategoryClickListener {
	
	public void click(View v,Category category);
	
}
