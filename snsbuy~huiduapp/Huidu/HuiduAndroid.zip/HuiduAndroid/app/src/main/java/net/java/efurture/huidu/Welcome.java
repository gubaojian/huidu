package net.java.efurture.huidu;

import net.java.efurture.huidu.common.BaseActivity;
import android.net.Uri;
import android.os.Bundle;

public class Welcome extends BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.simple);
	}

	@Override
	protected void onLoad(Uri uri) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onDestoryClean() {
		// TODO Auto-generated method stub
		
	}
	
}
