package net.java.efurture.huidu.config;

public class SystemConfig {

	
	public static final String ASSERT_DIR = "file:///android_asset/";
}
