package net.java.efurture.huidu.config;

/**
 * 参数名字
 * */
public class Params {
	
      public static final String ID = "id";
      
      public static final String KEYWORD = "keyword";
      
  	  public static final String PAGE_NUM = "pageNum";
  	  
  	  public static final String CATEGORY_IDS = "categoryIds";
  	  
  	  public static final String CATEGORY_ID  = "categoryId";
  	  
  	  public static final String NAME = "name";
  	  
  	  public static final String URL = "url";
  	  
  	  
  
}
