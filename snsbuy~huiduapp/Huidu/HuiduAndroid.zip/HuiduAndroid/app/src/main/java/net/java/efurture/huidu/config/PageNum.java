package net.java.efurture.huidu.config;


public class PageNum {
    public static final int FIRST_PAGE = 1;
}
