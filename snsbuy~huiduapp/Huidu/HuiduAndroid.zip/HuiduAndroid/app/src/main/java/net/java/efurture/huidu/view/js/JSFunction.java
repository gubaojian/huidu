package net.java.efurture.huidu.view.js;

import android.webkit.JavascriptInterface;

/**
 * js接口大全
 * */
public class JSFunction {
	
	
	@JavascriptInterface
	public void showFooter(){
		
	}

}
